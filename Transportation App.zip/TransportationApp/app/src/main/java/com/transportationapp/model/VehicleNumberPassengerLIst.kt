package com.transportationapp.model

data class VehicleNumberPassengerLIst(
    val `data`: ArrayList<VehicleNumberData>,
    val message: String,
    val status: Int
)

data class VehicleNumberData(
    val vehicle_no: String
)