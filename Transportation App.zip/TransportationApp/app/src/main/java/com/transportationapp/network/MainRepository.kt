package com.transportationapp.network

import com.transportationapp.model.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.Field


interface MainRepository {

    suspend fun driverLogin(
        email: String,
        password: String,
        device_token: String,
        device_type: String,
    ): Response<RegisterResponseModel>

    suspend fun vehicleSeat(
        token: String,
    ): Response<SeatResponse>


    suspend fun addloadervehical(
        token: String,
        driver_id: String,
        vehicle_owner_name: String,
        vehicle_name: String,
        year_of_model: String,
        vehicle_number: String,
        vehicle_type: String,
//        vehicle_category: String,
        capacity: String,
        height: String,
        color: String,
        no_of_tyres: String,
        body_type: String,
    ): Response<AddloaderResponse>

    suspend fun addpassengervehical(
        token: String,
        driver_id: String,
        vehicle_owner_name: String,
        vehicle_name: String,
        year_of_model: String,
        vehicle_number: String,
        vehicle_type: String,
//        vehicle_category: String,
        capacity: String,
        height: String,
        color: String,
        no_of_tyres: String,
        body_type: String,
        seat: String,
    ): Response<AddloaderResponse>
    suspend fun driverSendOtpApi(mobile : String) : Response<RegisterResponseModel>
    suspend fun DriverProfile(header: String,id:String): Response<DriverProfile>
    suspend fun loader_truck_repository_list_details(header: String,vehicle_id:String): Response<TaxiRepositoryViewDetailsResponse>
    suspend fun loader_truck_repository_image_list_details(header: String,vehicle_id:String): Response<TruckImagesModelCLass>
    suspend fun passengers_truck_repository_image_list(header: String,vehicle_id:String): Response<TruckImagesModelCLass>
    suspend fun loader_truck_repository_doc_list_details(header: String,vehicle_id:String): Response<TruckDocumentsDetailsResponse>
    suspend fun passengers_truck_repository_list_details(header: String,vehicle_id:String): Response<TaxiRepositoryViewDetailsResponse>
    suspend fun passengers_truck_repository_doc_list(header: String,vehicle_id:String): Response<TruckDocumentsDetailsResponse>
    suspend fun loader_truck_repository_list_delete(header: String,id:String): Response<DriverProfile>
    suspend fun passengers_truck_repository_list_delete(header: String,id:String): Response<DriverProfile>
    suspend fun EditProfile(
        token: String,
        name: RequestBody,
        email: RequestBody,
        mobile: RequestBody,
        address: RequestBody,
        device_token:RequestBody, device_type:RequestBody, device_id:RequestBody, Image: MultipartBody.Part
    ): Response<ProfileEditResponse>
    suspend fun FinalvehicalSubmit(
        token: String,
        driver_id: String
    ): Response<AddVehicalfinalResponse>
    suspend fun RideCompleted(header: String,id:String): Response<RideCompletedResponse>
    suspend fun DriverUpdateProfile(header: String,id: RequestBody,name:RequestBody,mobile_number:RequestBody,experience:RequestBody
                                    ,licence_number:RequestBody,device_token:RequestBody,device_type:RequestBody,device_id:RequestBody,password:RequestBody,profile_image:MultipartBody.Part): Response<DriverUpdateProfileResponse>
    suspend fun AcceptRide(header: String,booking_id: String,start_code:String): Response<Addmoneywallet>
    suspend fun OngoinTripHistory(header: String): Response<TripHistoryResponse>
    suspend fun LoaderCancelReason(header: String): Response<Loader_cancel_ReasonList_Response>
    suspend fun CompletedTripHistory(header: String): Response<TripHistoryResponse>
    suspend fun UpcomingsTripHistory(header: String): Response<TripHistoryResponse>
    suspend fun WalletList(header: String): Response<WalletListResponse>
   suspend fun loader_trip_delete(header: String,id:String): Response<DriverProfile>
   suspend fun vendor_driver_delete(header: String,id:String): Response<DriverProfile>
   suspend fun my_wallet_payment(header: String,type:String,transaction_id:String,amount: String): Response<DriverProfile>
   suspend fun add_bank_account(header: String,account_no:String,name:String,ifsc: String,bank_name: String,account_branch: String): Response<DriverProfile>
   suspend fun loader_builty_img(header: String,booking_id:RequestBody,pod:MultipartBody.Part?,signature:MultipartBody.Part?,builty:MultipartBody.Part?): Response<DriverProfile>

    suspend fun my_driver_wallet_list_donload(header: String): Response<ProfileResponse>
    suspend fun LoaderDriverTripCancel(header: String,booking_id: String,reason_id:String,reason:String): Response<LoaderDriverTripCancelResponse>
    suspend fun Addmoneywallet(header: String,amount:String): Response<Addmoneywallet>
    suspend fun CapacityApi(token: String): Response<LoaodCarryingResponse>
    suspend fun Filteredwallet(header: String,date:String,transaction_type:String): Response<WalletFilterLIstREsponse>
    suspend fun CompletedTripHistoryPassenger(header: String): Response<TripHistoryResponse>
    suspend fun VisitingCard(header: String): Response<VisitingCardUrlResponse>
    suspend fun OngoinTripHistoryPassenger(header: String): Response<TripHistoryResponse>
    suspend fun cancel_booking_history_loader(header: String): Response<TripHistoryResponse>
    suspend fun cnacel_booking_passengers(header: String): Response<TripHistoryResponse>
    suspend fun AddTrip(
        token: String,
        tip_task: String,
        load_caring: String,
        from_trip: String,
        to_trip: String,
        vehicle_type: String,
        vehicle_numbers: String,
        no_tyers: String,
        body_type: String,
        assign_driver: String,
        total_distance: String,
        freight_amount: String,
        pickup_lat: String,
        pickup_long: String,
        dropup_lat: String,
        dropup_long: String,
        vehicle_id: String,
        booking_date_from: String,
        booking_time: String,
    ): Response<CreateBusinesscard>

    suspend fun AddTripPassenger(
        token: String,
        tip_task: String,
        load_caring: String,
        from_trip: String,
        to_trip: String,
        vehicle_type: String,
        vehicle_numbers: String,
        no_tyers: String,
        body_type: String,
        assign_driver: String,
        total_distance: String,
        freight_amount: String,
        pickup_lat: String,
        pickup_long: String,
        dropup_lat: String,
        dropup_long: String,
        vehicle_id: String,
        booking_date_from: String,
        booking_time: String,
    ): Response<CreateBusinesscard>
    suspend fun driverChangePwd(
        token:String,
        password: String
    ): Response<RegisterResponseModel>

    suspend fun DeiselList(
        id: String
    ): Response<DeiselPrice>
    suspend fun driverList(
        token:String,
        vendor_id: String
    ): Response<DriverListResponse>
    suspend fun StateList(): Response<StateListResponse>
    suspend fun subscriptionplan(
        token: String
    ): Response<SubscriptionPlan>
    suspend fun Loadertruckrepositorypassengerlist(
        token: String
    ): Response<LoaderTruckRepositoryListResponse>

    suspend fun Loadertruckrepositorylist(
        token: String
    ): Response<LoaderTruckRepositoryListResponse>
    suspend fun PrivacyPolicy(header: String): Response<PrivacyPolicy>

    suspend fun TransactionReport(header: String): Response<TransactionReportResponse>

    suspend fun VisitingPdf(header: String): Response<DownloadPdfResponse>
    suspend fun InvoiceDownload(header: String,invoiceno:String): Response<DownloadPdfResponse>
    suspend fun Notification(header: String): Response<NotificationResponse>

    suspend fun driverVerifyOtp(otp: String, mobile: String, ): Response<RegisterResponseModel>
    suspend fun ContactUs(header: String): Response<ContactUSRsponse>
    suspend fun Rating(header: String): Response<RatingResponse>
    suspend fun Aboutus(header: String): Response<AboutUs>

    suspend fun TripList(header: String): Response<TripListResponse>
    suspend fun PassengerTripList(header: String): Response<TripListResponse>
    suspend fun self_driver_trip(header: String): Response<AddTripDriverMOdelClass>
    suspend fun self_driver_passenger_trip(header: String): Response<AddTripDriverMOdelClass>
    suspend fun InvoiceList(header: String): Response<InvoiceListResponse>

    suspend fun LoaderinvoiceSummery(header: String,invoice_numbers:String): Response<InvoiceSummeryResponse>
    suspend fun ForgotPassword(
        mobile: String,
        password: String,
    ): Response<RegisterResponseModel>
//    suspend fun Loaderinvoice(header: String,invoice_numbers:String): Response<InvoiceResponse>

    suspend fun GetProfile(token: String, ): Response<ProfileResponse>

    suspend fun Completedrivertripdetails(header: String,booking_id:String): Response<CompleteDriverDetailsResponse>
    suspend fun Completedriverpassengertripdetails(header: String,booking_id:String): Response<CompleteDriverDetailsResponse>
    suspend fun Senddriverloaderinvoice(header: String,booking_id:String): Response<SendDriverLoaderInvoiceResponse>
    suspend fun termsAPi(
        header: String
    ): Response<RegisterResponseModel>

    suspend fun aboutUs(
        header: String
    ): Response<RegisterResponseModel>

    suspend fun privacypolicy(
        header: String
    ): Response<RegisterResponseModel>

    suspend fun contactus(
        header: String
    ): Response<RegisterResponseModel>

    suspend fun truckTypeApi(
    ): Response<TruckTypeResponse>

    suspend fun TypeofTruckApi(
        header: String
    ): Response<TypeofTruckResponse>

    suspend fun BodyTypeApi(
        header: String
    ): Response<BodyType>

    suspend fun HightApi(
        header: String
    ): Response<hightResponse>

    suspend fun ColorApi(
        header: String
    ): Response<ColorResponse>

    suspend fun YearApi(
        header: String
    ): Response<YearResponse>

    suspend fun vehicalwheels(
        header: String
    ): Response<vehicalwheelsResponse>

    suspend fun Businessdata(
        header: String
    ): Response<BusinessListResponse>



    suspend fun getProfile(   header: String
    ): Response<ListResponseData>
    /*
      suspend fun viewProfile(
          token: String,
      ): Response<ViewProfileResponseModel>

      suspend fun updateProfileApi(
          token: String,
          name: RequestBody,
          bio:RequestBody,
          email: RequestBody,
          gender: RequestBody,
          image: MultipartBody.Part,
      ): Response<LoginResponseModel>

      suspend fun dashboardApi(
          token: String,
      ): Response<DashboardResponseModel>

      suspend fun postLikeApi(
          token: String,
          post_id:String,
          type:String
      ): Response<CommonDataResponse>

      suspend fun voteApi(
          token: String,
          post_id:String,
         vote:String
      ): Response<CommonDataResponse>
  */
    suspend fun driverSignupApi(
        name: String,
        mobile: String,
        email: String,
        gst_number: String,
        password: String,
        role: String,
//        type_vehicle: String,
        device_type: String,
        device_name: String,
        device_token: String,
        device_id: String,
    ): Response<RegisterResponseModel>

    suspend fun BusinesscardApi(
        token: String,
        Company: RequestBody,
        name: RequestBody,
        mobile: RequestBody,
        email: RequestBody,
        address: RequestBody,
        image: MultipartBody.Part,
    ): Response<CreateBusinesscard>

    suspend fun LoaderVehicleimage(
        token: String,
        vehicle_id: RequestBody,
        Image: MultipartBody.Part,
    ): Response<Loaderimage>

    suspend fun passengerVehicleimg(
        token: String,
        vehicle_id: RequestBody,
        Image: MultipartBody.Part
    ): Response<Loaderimage>
    suspend fun UpcomingsPassengerTripHistory(header: String): Response<TripHistoryResponse>
    suspend fun Passengervehicledoc(
        token: String,
        vehicle_id: RequestBody,
        doc_name: RequestBody,
        Doc: MultipartBody.Part
    ): Response<Loaderimage>

    suspend fun GetVehicle(
        token: String,
    ): Response<VehicleList>
   suspend fun get_passenger_vehicleno(
        token: String,
    ): Response<VehicleNumberPassengerLIst>

    suspend fun get_loder_vehicleno(
        token: String,
    ): Response<VehicleNumberListMOdelCLass>


    suspend fun loderfarecalculator(
        token: String,
        pickup_lat:String,
        pickup_long:String,
        dropup_lat:String,
        dropup_long:String,
        mileage:String,
        vehicle_type:String
    ): Response<FareCaluculationResponse>

    suspend fun loader_vehicle_payment(
        token: String,
        id:String,subscribe:String,fare:String,payment_mode:String,
        transaction_id:String

    ): Response<AddDriverResponse>

  suspend fun add_passenger_vehicle_payment(
      token: String,
      id:String,subscribe:String,fare:String,payment_mode:String,
      transaction_id:String
    ): Response<AddDriverResponse>

    suspend fun FinalpassengervehicalSubmit(
        token: String,
        driver_id: String
    ): Response<AddVehicalfinalResponse>

    suspend fun Loadervehicledoc(
        token: String,
        vehicle_id: RequestBody,
        doc_name: RequestBody,
        Doc: MultipartBody.Part,
    ): Response<Loaderimage>

    suspend fun AdddriverApi(
        token: String,
        drivername: RequestBody,
        driverexperience: RequestBody,
        Licence: RequestBody,
        mobile: RequestBody,
        email: RequestBody,
        Password: RequestBody,
        Image: MultipartBody.Part,
        pdfFile:MultipartBody.Part,
        vendorid:RequestBody,
        serviceid:RequestBody,
    ): Response<AddDriverResponse>
}


