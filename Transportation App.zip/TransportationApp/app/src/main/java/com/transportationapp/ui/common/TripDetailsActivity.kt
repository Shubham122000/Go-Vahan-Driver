package com.transportationapp.ui.common

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.transportationapp.R
import com.transportationapp.adapter.CancelReasonAdapter
import com.transportationapp.adapter.CompletedTripAdapter
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityTripDetailsBinding
import com.transportationapp.databinding.DialogCancelTripBinding
import com.transportationapp.model.Loader_cancel_ReasonList_ResponseData
import com.transportationapp.ui.vendor.TrackVehicleActivity
import com.transportationapp.ui.vendor.TripDetailsAssignActivity
import com.transportationapp.utils.Canceldata
import com.transportationapp.utils.toast
import com.transportationapp.viewmodel.InvoiceViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TripDetailsActivity : BaseActivity(),Canceldata {
    private lateinit var binding : ActivityTripDetailsBinding
    private val viewModel: InvoiceViewModel by viewModels()
    lateinit var Bookingid :String
    lateinit var invoicenumber :String
    lateinit var Bookingstatus :String
    lateinit var canselreasonadapter :CancelReasonAdapter
    lateinit var cancelid : String
    lateinit var cancelreason : String
    var flag : String =""

    private  var etfromlat = 0.0
    private  var etfromlong = 0.0
    private  var ettolat = 0.0
    private  var ettolong = 0.0
    var Listdata :ArrayList<Loader_cancel_ReasonList_ResponseData> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_trip_details)

        if (intent!=null){
            Bookingid = intent.getStringExtra("bookingid").toString()
            flag = intent.getStringExtra("flag").toString()
        }
        binding.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })

        binding.btnRejecttrip.setOnClickListener(View.OnClickListener {
            cancelDialog()
        })


        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        if (flag == "upcomingpassenger"){
            viewModel.CompletedtrippassengerdetailsAPI(
                "Bearer "+ userPref.getToken().toString(),
                Bookingid
//        ,"Book21530"
            )
        }else if(flag == "upcomingloader"){
            viewModel.CompletedtripdetailsAPI(
                "Bearer "+ userPref.getToken().toString(),
                Bookingid
//        ,"Book21530"
            )
        }

        viewModel.CompleteDriverDetailsResponse.observe(this) {
            if (it?.status == 1) {
                try {
                    if (it.userDetails !=  null) {
                        binding.tvName.text = it.userDetails?.name.toString()
                        binding.tvPhone.text = it.userDetails?.mobileNumber.toString()
                        binding.tvEmail.text = it.userDetails?.email.toString()
                    }
                    if (it.data != null) {
                        binding.tvTruckname.text = it.data?.vehicleName.toString()
                        binding.tvNumber.text = it.data?.vehicleNumbers.toString()
                        binding.tvType.text = it.data?.bodyname.toString()
                        binding.tvCapacity.text = it.data?.capacity.toString()
                        binding.tvHeight.text = it.data?.height.toString()
                        binding.tvHead.text = "Booking id: "+it.data?.bookingId.toString()
                        binding.tvDistance.text = it.data?.distance.toString()
                        binding.tvFrom.text = it.data?.picupLocation.toString()
                        binding.tvTo.text = it.data?.dropLocation.toString()
                        binding.tvAmount.text = "₹" + it.data?.fare.toString()
                        binding.tvDrivername.text = it.ownerDetails?.name.toString()
                        binding.tvDriverphone.text = it.ownerDetails?.mobile.toString()
                        binding.tvLicno.text = it.ownerDetails?.licenseno.toString()
                        invoicenumber = it.data?.invoiceNumber.toString()
                        Bookingstatus = it.data?.bookingStatus.toString()

                        etfromlat = it.data?.picupLat!!.toDouble()
                        etfromlong = it.data?.picupLong!!.toDouble()
                        ettolat = it.data?.dropLat!!.toDouble()
                        ettolong = it.data?.dropLong!!.toDouble()

                    }
                }catch (e:Exception){
                    e.printStackTrace()
                }


            } else {

            }
        }
        binding.btnAccepttrip.setOnClickListener(View.OnClickListener {
            if (binding.etStartRide.text.toString().isNullOrEmpty()){
                snackbar("Please enter start ride code")
            }else{
                viewModel.AcceptRideAPI(
                    "Bearer "+ userPref.getToken().toString(),
                    Bookingid,
                    binding.etStartRide.text.toString()
                )
            }
        })
        viewModel.acceptRide.observe(this) {
            if (it?.status == 1) {
                try {
                    toast(it.message)
                    val intent = Intent(this, TrackingActivity::class.java)
                    intent.putExtra("distance",binding.tvDistance.text.toString())
                    intent.putExtra("amount",binding.tvAmount.text.toString())
                    intent.putExtra("etfrom",binding.tvFrom.text.toString())
                    intent.putExtra("etto",binding.tvTo.text.toString())
                    intent.putExtra("piclat",etfromlat.toDouble())
                    intent.putExtra("piclong",etfromlong.toDouble())
                    intent.putExtra("droplat",ettolat.toDouble())
                    intent.putExtra("droplong",ettolong.toDouble())
                    intent.putExtra("Bookingid",Bookingid)
                    startActivity(intent)

                }catch (e:Exception){
                    e.printStackTrace()
                }
            }else {
                toast(it.message)
            }
        }
    }
    override fun idreason(reasonid: String) {
        cancelid = reasonid
//        cancelreason = reason
    }

    private fun cancelDialog() {
        val cDialog = Dialog(this, R.style.Theme_Tasker_Dialog)
        val bindingDialog: DialogCancelTripBinding = DataBindingUtil.inflate(
            LayoutInflater.from(this),
            R.layout.dialog_cancel_trip,
            null,
            false
        )

        cDialog.setContentView(bindingDialog.root)
        cDialog.setCancelable(false)
        cDialog.window!!.setLayout(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT
        )
        cDialog.show()


        viewModel.Loader_cancel_ReasonList_Response.observe(this) {
            if (it?.status == 1) {
                Listdata.clear()
                Listdata.addAll(it.data)
                bindingDialog.rvReasons.layoutManager = LinearLayoutManager(this)
                canselreasonadapter = CancelReasonAdapter(this, Listdata,this)
                bindingDialog.rvReasons.adapter =canselreasonadapter

////                userPref.setUserId(it!!.data!!.Id.toString())
//                val intent = Intent(this, DashboardActivity::class.java)
//                startActivity(intent)
//                finish()
            } else {
//                toast(.message)
            }
        }


        bindingDialog.ivClose.setOnClickListener(View.OnClickListener {
            cDialog.dismiss()
        })
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.LoadercancelReasonAPI(
            "Bearer "+ userPref.getToken().toString(),
        )



        bindingDialog.btnCancel.setOnClickListener {
            cancelreason = bindingDialog.etFeedback.text.toString()
            viewModel.LoaderDriverTripCancelAPI(
                "Bearer "+ userPref.getToken().toString(),
                Bookingid,
                cancelid,
                cancelreason
            )
            viewModel.LoaderdrivertripcancelResponse.observe(this) {
                if (it?.status == 1) {
                    toast(it.message)
                    cDialog.dismiss()
                } else {
                toast(it.message)
                }
            }
        }
    }


}