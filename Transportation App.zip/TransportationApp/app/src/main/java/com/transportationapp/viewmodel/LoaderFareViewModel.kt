package com.transportationapp.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.transportationapp.model.FareCaluculationResponse
import com.transportationapp.model.TypeofTruckResponse
import com.transportationapp.model.TypeofTruckResponseData
import com.transportationapp.network.MainRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class LoaderFareViewModel @Inject constructor(private val mainRepository: MainRepository) :ViewModel() {
    val progressBarStatus = MutableLiveData<Boolean>()
    val farecalculationResponse = MutableLiveData<FareCaluculationResponse>()
    var truckTypeResponse = MutableLiveData<TypeofTruckResponse>()
    val _progressBarVisibility = MutableLiveData<Int>()
    var truckTypeData = MutableLiveData<ArrayList<TypeofTruckResponseData>>()

    fun TypeofTruckApi(token :String): MutableLiveData<TypeofTruckResponse> {
        if (truckTypeResponse == null) {
            truckTypeResponse = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.TypeofTruckApi(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    truckTypeResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return truckTypeResponse
    }
    fun farecalculatorApi(
        token: String,
        pickup_lat: String,
        pickup_long: String,
        dropup_lat: String,
        dropup_long: String,
        mileage: String,
        vehicle_type: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response =
                mainRepository.loderfarecalculator(token,pickup_lat,pickup_long,dropup_lat,dropup_long,mileage,vehicle_type)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                farecalculationResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }
}