package com.transportationapp.model

import com.google.gson.annotations.SerializedName

data class TypeofTruckResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<TypeofTruckResponseData> = arrayListOf()
)
data class TypeofTruckResponseData(
    @SerializedName("id"         ) var id        : Int?    = null,
    @SerializedName("v_type"     ) var v_type    : String? = null,
    @SerializedName("status"     ) var status    : Int?    = null,
    @SerializedName("created_at" ) var createdAt : String? = null,
    @SerializedName("updated_at" ) var updatedAt : String? = null
){
    override fun toString(): String {
        return v_type.toString()
    }
}
