package com.transportationapp.ui.driver

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.transportationapp.R
import com.transportationapp.adapter.TripAdapter
import com.transportationapp.base.BaseActivity
import com.transportationapp.customclick.tripdelete
import com.transportationapp.databinding.ActivityTriplistBinding
import com.transportationapp.model.TripListResponseData
import com.transportationapp.viewmodel.TripHistoryViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.util.ArrayList

@AndroidEntryPoint
class TriplistActivity : BaseActivity(),tripdelete {
    private lateinit var binding : ActivityTriplistBinding
    lateinit var adapter : TripAdapter
    private val viewModel: TripHistoryViewModel by viewModels()
    var Listdata: ArrayList<TripListResponseData> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding = DataBindingUtil.setContentView(this,R.layout.activity_triplist)

        binding.ivBack.setOnClickListener {
            finish()
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.TriplistApi(
            "Bearer "+ userPref.getToken().toString(),
        )
        viewModel.TriplistResponse.observe(this) {
            if (it?.status == 1) {
                Listdata.clear()
                Listdata.addAll(it.data)
                binding.rvtriplit.layoutManager = LinearLayoutManager(this)
                adapter = TripAdapter(this, Listdata,this)
                binding.rvtriplit.adapter = adapter

            } else {
            }

        }

        viewModel.DeleteTRipComplete.observe(this) {
            if (it?.status == 1) {
                viewModel.TriplistApi(
                    "Bearer "+ userPref.getToken().toString(),
                )

            } else {
            }

        }    }

    override fun tripdelete(id: String) {
        viewModel.DeleteTripHistory(
            "Bearer "+ userPref.getToken().toString(),id
        )
    }
}