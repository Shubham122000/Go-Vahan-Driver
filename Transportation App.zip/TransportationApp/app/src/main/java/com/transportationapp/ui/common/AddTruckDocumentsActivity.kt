package com.transportationapp.ui.common

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.Nullable
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.databinding.DataBindingUtil
import com.bumptech.glide.Glide
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.transportationapp.R
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityAddTruckDocumentsBinding
import com.transportationapp.databinding.ActivitySubscriptionPlanPactivityBinding
import com.transportationapp.model.*
import com.transportationapp.permission.RequestPermission
import com.transportationapp.ui.DashboardActivity
import com.transportationapp.ui.vendor.DriverListActivity
import com.transportationapp.ui.vendor.VendorsSubscriptionPlanActivity
import com.transportationapp.utils.toast
import com.transportationapp.viewmodel.TypeOfTruckViewModel
import dagger.hilt.android.AndroidEntryPoint
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

@AndroidEntryPoint
class AddTruckDocumentsActivity : BaseActivity() {

    private lateinit var binding : ActivityAddTruckDocumentsBinding
    private val viewModel : TypeOfTruckViewModel by viewModels()
    var truckdata : ArrayList<TypeofTruckResponseData> = ArrayList()
    var Bodydata : ArrayList<BodyTypeData> = ArrayList()
    var Hightdata : ArrayList<hightResponseData> = ArrayList()
    var wheels : ArrayList<vehicalwheelsResponseData> = ArrayList()
    var colordata : ArrayList<ColorResponseData> = ArrayList()
    var yeardata : ArrayList<YearResponseData> = ArrayList()
    var nametype :ArrayList<String> = ArrayList()
    var Bodytype :ArrayList<String> = ArrayList()
    var Highttype :ArrayList<String> = ArrayList()
    var vehicalwheel :ArrayList<String> = ArrayList()
    var colors :ArrayList<String> = ArrayList()
    var year :ArrayList<String> = ArrayList()
    var id_body :ArrayList<String> = ArrayList()
    var id_hight :ArrayList<String> = ArrayList()
    var id_wheels :ArrayList<String> = ArrayList()
    var id_color :ArrayList<String> = ArrayList()
    var id_year :ArrayList<String> = ArrayList()
    var amount:Int=0
    var finalPamountInt=0
    val CAMERA_PERM_CODE_ID_Front = 101
    var imageFile: File? = null
    var imagePath = ""
    var photoURI: Uri? = null
    lateinit var imageprats: MultipartBody.Part
    private val GALLERY_ID_FRONT = 1
    private var CAMERA_ID_FRONT: Int = 2
    lateinit var image: Uri
    var flag: String = ""
    var flagforpdf: String = ""




//    private lateinit var dionrealog: Dialog
var imagetruck1: MultipartBody.Part? = null
var imagetruck2: MultipartBody.Part? = null
var imagetruck3: MultipartBody.Part? = null
var imagetruck4: MultipartBody.Part? = null

    val CAMERA_PERM_CODE_ID_BACK = 102

    //    var imageFile: File? = null
//    var imagePath = ""
//    var photoURI: Uri? = null
//    lateinit var imageparts: MultipartBody.Part
    private val GALLERY_ID_BACK = 3
    private var CAMERA_ID_BACK: Int = 4
//    lateinit var image: Uri
//    var requestImage: String = ""
val CAMERA_PERM_CODE_LICENSE_BACK = 104
    val CAMERA_PERM_CODE_LICENSE_FRONT = 103
    private val GALLERY_LICENSE_FRONT = 5
    private var CAMERA_LICENSE_FRONT: Int = 6

    private val GALLERY_LICENSE_BACK = 7
    private var CAMERA_LICENSE_BACK: Int = 8
    var selectedTruckTypeId=""
    var selectedBodyId=""
    var selectedHightId=""
    var selectedWheelsId=""
    var selectedColorId=""
    var selectedYearId=""
    var vehicleid : String =""
    var Capacity : ArrayList<LoadCarryingData> = ArrayList()
    var Capacitytype :ArrayList<String> = ArrayList()
    var id_Capacity :ArrayList<String> = ArrayList()
    //For Pdf Upload
    var pdfFile: MultipartBody.Part? = null
    var pdfFile1: MultipartBody.Part? = null
    var pdfFile2: MultipartBody.Part? = null
    var pdfFile3: MultipartBody.Part? = null
    var pdfFile4: MultipartBody.Part? = null
    private val pickPdf = 9
    private val pickPdf1 = 10
    private val pickPdf2 = 11
    private val pickPdf3 = 12
    private val pickPdf4 = 13

    val FILE_BROWSER_CACHE_DIR = "doc"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_add_truck_documents)

        binding.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })
//        binding.btnSubmit.setOnClickListener {
//            val intent = Intent(this, VendorsSubscriptionPlanActivity::class.java)
//            startActivity(intent)
//        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.TypeofTruckApi(
            "Bearer "+userPref.getToken().toString(),
        ).observe(this) {

            if (it!!.status == 1) {
                truckdata.clear()
                nametype.clear()
                truckdata.addAll(it!!.data)
                viewModel.truckTypeData.value = it.data
                for (i in 0 until it.data.size) {
                    nametype.add(it.data[i].v_type.toString())
                }
                val spinnerArrayAdapter: ArrayAdapter<String> = ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_spinner_dropdown_item,
                    nametype
                )
                spinnerArrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.spinnerTrucktype.adapter = spinnerArrayAdapter
            }
        }

        viewModel.BodyType(
            "Bearer "+userPref.getToken().toString(),
        ).observe(this) {

            if (it!!.status == 1) {
                Bodydata.clear()
                Bodytype.clear()
                Bodydata.addAll(it.data)
                viewModel.BodyTypeData.value = it.data
                for (i in 0 until it.data.size) {
                    Bodytype.add(it.data[i].name.toString())
                    id_body.add(it.data[i].id.toString())
                }
                val spinnerArrayAdapter2: ArrayAdapter<String> = ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_spinner_dropdown_item,
                    Bodytype
                )
                spinnerArrayAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.spinnerBadytype.adapter = spinnerArrayAdapter2
            }
        }

        viewModel.HightType(
            "Bearer "+userPref.getToken().toString(),
        ).observe(this) {

            if (it!!.status == 1) {
                Hightdata.clear()
                Highttype.clear()
                Hightdata.addAll(it.data)
                viewModel.HeightTypeData.value = it.data
                for (i in 0 until it.data.size) {
                    Highttype.add(it.data[i].height.toString())
                    id_hight.add(it.data[i].id.toString())
                }
                val spinnerArrayAdapter3: ArrayAdapter<String> = ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_spinner_dropdown_item,
                    Highttype
                )
                spinnerArrayAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.spinnerHeight.adapter = spinnerArrayAdapter3
            }
        }
                viewModel.Vehicalwheels(
                    "Bearer "+userPref.getToken().toString(),
                ).observe(this) {

                    if (it!!.status == 1) {
                        wheels.clear()
                        vehicalwheel.clear()
                        wheels.addAll(it.data)
                        viewModel.VehicalwheelsData.value = it.data
                        for (i in 0 until it.data.size) {
                            vehicalwheel.add(it.data[i].wheel.toString())
                            id_wheels.add(it.data[i].id.toString())
                        }
                        val spinnerArrayAdapter4: ArrayAdapter<String> = ArrayAdapter<String>(
                            this,
                            android.R.layout.simple_spinner_dropdown_item,
                            vehicalwheel
                        )
                        spinnerArrayAdapter4.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                        binding.spinnerTyrenumber.adapter = spinnerArrayAdapter4
                    }
                }

        viewModel.Color(
            "Bearer "+userPref.getToken().toString(),
        ).observe(this) {

            if (it!!.status == 1) {
                colordata.clear()
                colors.clear()
                colordata.addAll(it.data)
                viewModel.Colordata.value = it.data
                for (i in 0 until it.data.size) {
                    colors.add(it.data[i].vColor.toString())
                    id_color.add(it.data[i].id.toString())
                }
                val spinnerArrayAdapter5: ArrayAdapter<String> = ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_spinner_dropdown_item,
                    colors
                )
                spinnerArrayAdapter5.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.spinnerColor.adapter = spinnerArrayAdapter5
            }
        }

        viewModel.Year(
            "Bearer "+userPref.getToken().toString(),
        ).observe(this) {
            if (it!!.status == 1) {
                yeardata.clear()
                year.clear()
                yeardata.addAll(it.data)
                viewModel.Yearresponsedata.value = it.data
                for (i in 0 until it.data.size) {
                    year.add(it.data[i].model.toString())
                    id_year.add(it.data[i].id.toString())
                }
                val spinnerArrayAdapter6: ArrayAdapter<String> = ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_spinner_dropdown_item,
                    year
                )
                spinnerArrayAdapter6.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.spinnerYearofmodel.adapter = spinnerArrayAdapter6
            }
        }

        viewModel.AddloaderResponse.observe(this) {
            if (it?.status == 1) {
                Toast.makeText(this, "Vehical added Successfully...", Toast.LENGTH_LONG).show()
                vehicleid = it.id.toString()
            } else {
                //toast(it.message)
                snackbar(it?.message!!)
            }
        }
        binding.spinnerTrucktype.onItemSelectedListener = object : OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                selectedTruckTypeId=nametype[p2]
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

        }
        binding.spinnerYearofmodel.onItemSelectedListener = object : OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                selectedYearId=id_year[p2]
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

        }
        binding.spinnerHeight.onItemSelectedListener = object : OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                selectedHightId=id_hight[p2]
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

        }
        binding.spinnerColor.onItemSelectedListener = object : OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                selectedColorId=id_color[p2]
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

        }
        binding.spinnerTyrenumber.onItemSelectedListener = object : OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                selectedWheelsId=id_wheels[p2]
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

        }
        binding.spinnerBadytype.onItemSelectedListener = object : OnItemSelectedListener{
            override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                selectedBodyId=id_body[p2]
            }

            override fun onNothingSelected(p0: AdapterView<*>?) {

            }

        }

        binding.ivTruck1.setOnClickListener {
            flag = "firstone"
            RequestPermission.requestMultiplePermissions(this)
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CAMERA),
                    CAMERA_PERM_CODE_ID_Front
                )
            } else {
                selectImage()
            }
        }
        binding.ivTruck2.setOnClickListener {
            flag = "secondone"
            RequestPermission.requestMultiplePermissions(this)
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CAMERA),
                    CAMERA_PERM_CODE_ID_BACK
                )
            } else {
                selectImage()
            }
        }
        binding.ivTruck3.setOnClickListener {
            flag = "thirdone"
            RequestPermission.requestMultiplePermissions(this)
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CAMERA),
                    CAMERA_PERM_CODE_LICENSE_FRONT
                )
            } else {
                selectImage()
            }
        }
        binding.ivTruck4.setOnClickListener {
            flag = "fourthone"
            RequestPermission.requestMultiplePermissions(this)
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.CAMERA),
                    CAMERA_PERM_CODE_LICENSE_BACK
                )
            } else {
                selectImage()
            }
        }

        binding.btnSubmit.setOnClickListener {
            if (binding.etTruckownername.text.isNullOrEmpty()) {
                toast("Please enter Username.")
            }else if (binding.etVehivalnumber.text.toString().isNullOrEmpty()) {
                toast("Please enter Vehical Number")
            }else {
                viewModel.Addloadervehical(
                    "Bearer "+userPref.getToken().toString(),
                    userPref.getid().toString(),
                    binding.etTruckownername.text.toString(),
//                    binding.etTruckname.text.toString(),
                    binding.spinnerTrucktype.selectedItem.toString(),
                    binding.spinnerYearofmodel.selectedItem.toString(),
                    binding.etVehivalnumber.text.toString(),
                    binding.spinnerTrucktype.selectedItem.toString(),
                    binding.etCapacity.text.toString(),
                    binding.spinnerHeight.selectedItem.toString(),
                    binding.spinnerColor.selectedItem.toString(),
                    binding.spinnerTyrenumber.selectedItem.toString(),
                    binding.spinnerBadytype.selectedItem.toString()
                )
            }
        }


        viewModel.AddVehicalfinalResponse.observe(this){
            if (it!!.status == 1) {
                finish()
//                val intent = Intent(this, VendorsSubscriptionPlanActivity::class.java)
//                    .putExtra("flag1","loader")
//                    .putExtra("vehicle_owner_name", binding.etTruckownername.text.toString())
//                    .putExtra("vehicle_id", vehicleid)
//                    .putExtra("vehicle_name",binding.spinnerTrucktype.selectedItem.toString())
//                    .putExtra("model_year",selectedYearId)
//                    .putExtra("vehicle_number",binding.etVehivalnumber.text.toString())
//                    .putExtra("vehicle_type",selectedTruckTypeId)
//                    .putExtra("capacity",binding.etCapacity.text.toString())
//                    .putExtra("height",selectedHightId)
//                    .putExtra("number_of_tyres",selectedWheelsId)
//                    .putExtra("bodytype",selectedBodyId)
//                startActivity(intent)
            }else{
                Toast.makeText(this, it.message.toString(), Toast.LENGTH_SHORT).show()
            }
        }
        viewModel.Loaderimage.observe(this){
            if (it!!.status == 1) {
                Toast.makeText(this, it.message.toString(), Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(this, it.message.toString(), Toast.LENGTH_SHORT).show()
            }
        }
        binding.llpdf1.setOnClickListener {

            flagforpdf = "firstone"
            selectPdf()
        }
        binding.llpdf2.setOnClickListener {

            flagforpdf = "secondone"
            selectPdf()
        }
        binding.llpdf3.setOnClickListener {

            flagforpdf = "thirdone"
            selectPdf()
        }
        binding.llpdf4.setOnClickListener {

            flagforpdf = "fourthone"
            selectPdf()
        }
        binding.llpdf5.setOnClickListener {

            flagforpdf = "fifthone"
            selectPdf()
        }
        binding.btnFinalsubmit.setOnClickListener {
            viewModel.AddVehicalfinalApi(
                "Bearer "+userPref.getToken().toString(),
                vehicleid
            )

        }
    }


    private fun selectPdf() {
        val pdfIntent = Intent(Intent.ACTION_GET_CONTENT)
        pdfIntent.type = "*/*"
        if (flagforpdf == "firstone"){
            startActivityForResult(pdfIntent, pickPdf)
        }else if (flagforpdf == "secondone"){
            startActivityForResult(pdfIntent, pickPdf1)
        }else if (flagforpdf == "thirdone"){
            startActivityForResult(pdfIntent, pickPdf2)
        }else if (flagforpdf == "fourthone"){
            startActivityForResult(pdfIntent, pickPdf3)
        }else if (flagforpdf == "fifthone"){
            startActivityForResult(pdfIntent, pickPdf4)

        }
    }

    private fun selectImage() {
        // on below line we are creating a new bottom sheet dialog.
        val dialog = BottomSheetDialog(this)
        // on below line we are inflating a layout file which we have created.
        val view = layoutInflater.inflate(R.layout.bottom_drawer, null)

        // below line is use to set cancelable to avoid
        // closing of dialog box when clicking on the screen.
        dialog.setCancelable(true)

        val CameraButton = view.findViewById<TextView>(R.id.camera_open)
        CameraButton.setOnClickListener {
            val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)

            if (takePictureIntent.resolveActivity(this.getPackageManager()) != null) {
                try {
                    imageFile = createImageFile()!!
                } catch (ex: IOException) {
                }
                if (imageFile != null) {
                    photoURI = FileProvider.getUriForFile(this, "com.transportationapp.fileprovider", imageFile!!
                    )
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    if (flag == "firstone") {
                        startActivityForResult(takePictureIntent, CAMERA_ID_FRONT)
                    } else if (flag == "secondone") {
                        startActivityForResult(takePictureIntent, CAMERA_ID_BACK)
                    } else if (flag == "thirdone") {
                        startActivityForResult(takePictureIntent, CAMERA_LICENSE_FRONT)
                    } else if (flag == "fourthone") {
                        startActivityForResult(takePictureIntent, CAMERA_LICENSE_BACK)
                    }

                    dialog.dismiss()
                }
            }
        }

        val GalleryButton = view.findViewById<TextView>(R.id.gallery_open)
        GalleryButton.setOnClickListener {
            val intent =
                Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            intent.type = "image/*"
            if (flag == "firstone") {
                startActivityForResult(intent, GALLERY_ID_FRONT)
            } else if (flag == "secondone") {
                startActivityForResult(intent, GALLERY_ID_BACK)
            } else if (flag == "thirdone") {
                startActivityForResult(intent, GALLERY_LICENSE_FRONT)
            } else if (flag == "fourthone") {
                startActivityForResult(intent, GALLERY_LICENSE_BACK)
            }
//            startActivityForResult(intent, GALLERY)
            dialog.dismiss()
        }
        val cancel = view.findViewById<TextView>(R.id.cancel)
        cancel.setOnClickListener {
            dialog.dismiss()
        }

        // on below line we are setting
        // content view to our view.
        dialog.setContentView(view)

        // on below line we are calling
        // a show method to display a dialog.
        dialog.show()
    }

    @Throws(IOException::class)
    private fun createImageFile(): File? {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss").format(Date())
        val imageFileName = "JPEG_" + timeStamp + "_"
        val storageDir =
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
        val image = File.createTempFile(
            imageFileName,
            ".jpg",
            storageDir
        )

        imagePath = image.absolutePath
        return image
    }


    private fun getPathFromURI(contentUri: Uri?): String? {
        var res: String? = null
        val proj = arrayOf(MediaStore.Images.Media.DATA)
        val cursor: Cursor? =
            this.contentResolver.query(contentUri!!, proj, null, null, null)
        if (cursor!!.moveToFirst()) {
            val column_index: Int = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA)
            res = cursor.getString(column_index)
        }
        cursor.close()
        return res
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
//        super.onActivityResult(requestCode, resultCode, data)
//        if (resultCode == Activity.RESULT_CANCELED) {
//            return
//        }
        if (requestCode == GALLERY_ID_FRONT) {
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    image = data.data!!
                    val path = getPathFromURI(image)

                    if (path != null) {
                        imageFile = File(path)
                        Glide.with(this).load(imageFile).into(binding.ivTruck1)
                        //   images.add(imageFile!!.absolutePath.toString())
                    }
                    //   images.add(path.toString())
                    val requestFile: RequestBody =
                        imageFile!!.asRequestBody("image/*".toMediaTypeOrNull())

                    imagetruck1 =MultipartBody.Part.createFormData(
                            "image",
                            imageFile?.name,
                            requestFile
                        )

                }
                viewModel.LoaderimageAPI(
                    "Bearer "+userPref.getToken().toString(),
                    vehicleid,
                    imagetruck1
                )


            }
        } else if (requestCode == CAMERA_ID_FRONT) {
            if (resultCode == RESULT_OK) {

                try {

                    imageFile = File(imagePath)
                    Glide.with(this).load(imageFile).into(binding.ivTruck1)
                    //   images.add(imageFile!!.absolutePath.toString())
                    val requestGalleryImageFile: RequestBody =
                        imageFile!!.asRequestBody("image/*".toMediaTypeOrNull())

                    imagetruck1 =
                        MultipartBody.Part.createFormData(
                            "image",
                            "",
                            requestGalleryImageFile
                        )
                    viewModel.LoaderimageAPI(
                        "Bearer "+userPref.getToken().toString(),
                        vehicleid,
                        imagetruck1
                    )

                } catch (e: java.lang.Exception) {
                }

            }
        } else if (requestCode == GALLERY_ID_BACK) {
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    image = data.data!!
                    val path = getPathFromURI(image)

                    if (path != null) {
                        imageFile = File(path)
                        Glide.with(this).load(imageFile).into(binding.ivTruck2)
                        //  images.add(imageFile!!.absolutePath.toString())

                    }
                    var requestGalleryImageFile: RequestBody =
                        imageFile!!.asRequestBody("image/*".toMediaTypeOrNull())

                    imagetruck2 =
                        MultipartBody.Part.createFormData(
                            "image",
                            "",
                            requestGalleryImageFile
                        )
                    viewModel.LoaderimageAPI(
                        "Bearer "+userPref.getToken().toString(),
                        vehicleid,
                        imagetruck2
                    )

//                    USER_IMAGE_UPLOADED = true
//                    if(USER_IMAGE_UPLOADED) {
//                        uploadUserImageApi()
//                    }
                }
            }
        } else if (requestCode == CAMERA_ID_BACK) {
            if (resultCode == RESULT_OK) {

                try {

                    imageFile = File(imagePath)
                    Glide.with(this).load(imageFile).into(binding.ivTruck2)
                    //  images.add(imageFile!!.absolutePath.toString())
//                        ProfileImage.setImageURI(Uri.fromFile(imageFile))
                    var requestGalleryImageFile: RequestBody =
                        imageFile!!.asRequestBody("image/*".toMediaTypeOrNull())

                    imagetruck2 =
                        MultipartBody.Part.createFormData(
                            "image",
                            imageFile!!.name,
                            requestGalleryImageFile
                        )
                    viewModel.LoaderimageAPI(
                        "Bearer "+userPref.getToken().toString(),
                        vehicleid,
                        imagetruck2
                    )
//                    USER_IMAGE_UPLOADED = true
//                    if(USER_IMAGE_UPLOADED) {
//                        uploadUserImageApi()
//                    }
                } catch (e: java.lang.Exception) {
                }
            }
        } else if (requestCode == GALLERY_LICENSE_FRONT) {
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    image = data.data!!
                    val path = getPathFromURI(image)

                    if (path != null) {
                        imageFile = File(path)
                        Glide.with(this).load(imageFile).into(binding.ivTruck3)
                    }
                    var requestGalleryImageFile: RequestBody =
                        imageFile!!.asRequestBody("image/*".toMediaTypeOrNull())

                    imagetruck3 =
                        MultipartBody.Part.createFormData(
                            "image",
                            imageFile!!.name,
                            requestGalleryImageFile
                        )

                    if (vehicleid.isNullOrEmpty()){
                        toast("Please ")
                    }
                    viewModel.LoaderimageAPI(
                        "Bearer "+userPref.getToken().toString(),
                        vehicleid,
                        imagetruck3
                    )
//                    USER_IMAGE_UPLOADED = true
//                    if(USER_IMAGE_UPLOADED) {
//                        uploadUserImageApi()
//                    }
                }
            }
        } else if (requestCode == CAMERA_LICENSE_FRONT) {
            if (resultCode == RESULT_OK) {
                try {
                    imageFile = File(imagePath)
                    Glide.with(this).load(imageFile).into(binding.ivTruck3)
//                        ProfileImage.setImageURI(Uri.fromFile(imageFile))
                    var requestGalleryImageFile: RequestBody =
                        imageFile!!.asRequestBody("image/*".toMediaTypeOrNull())

                    imagetruck3 =
                        MultipartBody.Part.createFormData(
                            "image",
                            imageFile!!.name,
                            requestGalleryImageFile
                        )
                    viewModel.LoaderimageAPI(
                        "Bearer "+userPref.getToken().toString(),
                        vehicleid,
                        imagetruck3
                    )

//                    USER_IMAGE_UPLOADED = true
//                    if(USER_IMAGE_UPLOADED) {
//                        uploadUserImageApi()
//                    }
                } catch (e: java.lang.Exception) {
                }
            }
        } else if (requestCode == GALLERY_LICENSE_BACK) {
            if (resultCode == RESULT_OK) {
                if (data != null) {
                    image = data.data!!
                    val path = getPathFromURI(image)

                    if (path != null) {
                        imageFile = File(path)
                        Glide.with(this).load(imageFile).into(binding.ivTruck4)

                    }
                    var requestGalleryImageFile: RequestBody =
                        imageFile!!.asRequestBody("image/*".toMediaTypeOrNull())

                    imagetruck4 =
                        MultipartBody.Part.createFormData(
                            "image",
                           "",
                            requestGalleryImageFile
                        )
                    viewModel.LoaderimageAPI(
                        "Bearer "+userPref.getToken().toString(),
                        vehicleid,
                        imagetruck4
                    )
//                    USER_IMAGE_UPLOADED = true
//                    if(USER_IMAGE_UPLOADED) {
//                        uploadUserImageApi()
//                    }
                }
            }
        } else if (requestCode == CAMERA_LICENSE_BACK) {
            if (resultCode == RESULT_OK) {

                try {
                    imageFile = File(imagePath)
                    Glide.with(this).load(imageFile).into(binding.ivTruck4)
//                        ProfileImage.setImageURI(Uri.fromFile(imageFile))
                    var requestGalleryImageFile: RequestBody =
                        imageFile!!.asRequestBody("image/*".toMediaTypeOrNull())

                    imagetruck4 =
                        MultipartBody.Part.createFormData(
                            "image",
                            imageFile!!.name,
                            requestGalleryImageFile
                        )
                    viewModel.LoaderimageAPI(
                        "Bearer "+userPref.getToken().toString(),
                        vehicleid,
                        imagetruck4
                    )
//                    USER_IMAGE_UPLOADED = true
//                    if(USER_IMAGE_UPLOADED) {
//                        uploadUserImageApi()
//                    }
                } catch (e: java.lang.Exception) {
                }
            }
        }else  if (requestCode == pickPdf) {

            val fileUris = data?.data
            var path= writeFileContent(fileUris!!)
            var fileSelected= File(path)

            binding.tvRcbook.text = fileSelected.absolutePath

            val requestFile: RequestBody = RequestBody.create(
                "multipart/form-data".toMediaTypeOrNull(),
                fileSelected)
            pdfFile = MultipartBody.Part.createFormData("doc", fileSelected.name, requestFile)
            //  viewModel.onUpdateCv(pdfFile)
            viewModel.LoaderdocAPI(
                "Bearer "+userPref.getToken().toString(),
                vehicleid,
                "Rc-book",
                pdfFile
            )

        }else  if (requestCode == pickPdf1) {

            val fileUris = data?.data
            var path= writeFileContent(fileUris!!)
            var fileSelected= File(path)
            binding.tvInsurancedoc.text = fileSelected.absolutePath
            val requestFile: RequestBody = RequestBody.create(
                "multipart/form-data".toMediaTypeOrNull(),
                fileSelected)
            pdfFile1 = MultipartBody.Part.createFormData("doc", fileSelected.name, requestFile)
            //  viewModel.onUpdateCv(pdfFile)
            viewModel.LoaderdocAPI(
                "Bearer "+userPref.getToken().toString(),
                vehicleid,
                "Insurance-Document",
                pdfFile1
            )

        }else  if (requestCode == pickPdf3) {

            val fileUris = data?.data
            var path= writeFileContent(fileUris!!)
            var fileSelected= File(path)

            binding.tvFitnessdoc.text = fileSelected.absolutePath

            val requestFile: RequestBody = RequestBody.create(
                "multipart/form-data".toMediaTypeOrNull(),
                fileSelected)
            pdfFile3 = MultipartBody.Part.createFormData("doc", fileSelected.name, requestFile)
            //  viewModel.onUpdateCv(pdfFile)
            viewModel.LoaderdocAPI(
                "Bearer "+userPref.getToken().toString(),
                vehicleid,
                "Fitness Papers",
                pdfFile3
            )

        }else  if (requestCode == pickPdf4) {

            val fileUris = data?.data
            var path= writeFileContent(fileUris!!)
            var fileSelected= File(path)

            binding.tvRtodoc.text = fileSelected.absolutePath

            val requestFile: RequestBody = RequestBody.create(
                "multipart/form-data".toMediaTypeOrNull(),
                fileSelected)
            pdfFile4 = MultipartBody.Part.createFormData("doc", fileSelected.name, requestFile)
            //  viewModel.onUpdateCv(pdfFile)
            viewModel.LoaderdocAPI(
                "Bearer "+userPref.getToken().toString(),
                vehicleid,
                "RTO Documents",
                pdfFile4
            )

        }
        else  if (requestCode == pickPdf2) {

            val fileUris = data?.data
            var path= writeFileContent(fileUris!!)
            var fileSelected= File(path)

            binding.tvPollutiondoc.text = fileSelected.absolutePath

            val requestFile: RequestBody = RequestBody.create(
                "multipart/form-data".toMediaTypeOrNull(),
                fileSelected)
            pdfFile2 = MultipartBody.Part.createFormData("doc", fileSelected.name, requestFile)
            //  viewModel.onUpdateCv(pdfFile)
            viewModel.LoaderdocAPI(
                "Bearer "+userPref.getToken().toString(),
                vehicleid,
                "Pollution-Document",
                pdfFile2
            )

        }

    }
    @Throws(IOException::class)
    private fun writeFileContent(uri: Uri): String? {
        val selectedFileInputStream = contentResolver.openInputStream(uri)
        if (selectedFileInputStream != null) {

            val mediaDir = externalMediaDirs.firstOrNull()?.let {
                File(it, resources.getString(R.string.app_name)).apply { mkdirs() }
            }

            val certCacheDir = File(mediaDir, FILE_BROWSER_CACHE_DIR)
            var isCertCacheDirExists = certCacheDir.exists()
            if (!isCertCacheDirExists) {
                isCertCacheDirExists = certCacheDir.mkdirs()
            }
            if (isCertCacheDirExists) {
                var fileName:String?=getFileDisplayName(uri)
                fileName!!.replace("[^a-zA-Z0-9]", " ")
                val filePath = certCacheDir.absolutePath.toString() + "/" +fileName
                val selectedFileOutPutStream: OutputStream = FileOutputStream(filePath)
                val buffer = ByteArray(1024)
                var length: Int
                while (selectedFileInputStream.read(buffer).also { length = it } > 0) {
                    selectedFileOutPutStream.write(buffer, 0, length)
                }
                selectedFileOutPutStream.flush()
                selectedFileOutPutStream.close()
                return filePath
            }
            selectedFileInputStream.close()
        }
        return null
    }
    @SuppressLint("Range")
    @Nullable
    private fun getFileDisplayName(uri: Uri): String? {
        var displayName: String? = null
        contentResolver
            .query(uri, null, null, null, null, null).use { cursor ->
                if (cursor != null && cursor.moveToFirst()) {
                    displayName = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME))
                }
            }
        return displayName
    }

}