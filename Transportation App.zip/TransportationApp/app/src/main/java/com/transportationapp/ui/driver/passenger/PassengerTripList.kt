package com.transportationapp.ui.driver.passenger

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import com.transportationapp.R
import com.transportationapp.adapter.PassengerTripListAdapter
import com.transportationapp.adapter.TripAdapter
import com.transportationapp.base.BaseActivity
import com.transportationapp.customclick.tripdelete
import com.transportationapp.databinding.ActivityPassengerTripListBinding
import com.transportationapp.databinding.ActivityTriplistBinding
import com.transportationapp.model.TripListResponseData
import com.transportationapp.viewmodel.TripHistoryViewModel
import java.util.ArrayList

class PassengerTripList : BaseActivity() ,tripdelete{
    lateinit var binding : ActivityPassengerTripListBinding
    lateinit var adapter : PassengerTripListAdapter
    private val viewModel: TripHistoryViewModel by viewModels()
    var Listdata: ArrayList<TripListResponseData> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_passenger_trip_list)

        binding.ivBack.setOnClickListener {
            finish()
        }

        viewModel.PassengerTriplistApi(
            "Bearer "+ userPref.getToken().toString(),
        )
        viewModel.TriplistResponse.observe(this) {
            if (it?.status == 1) {
                Listdata.clear()
                Listdata.addAll(it.data)
                binding.rvtriplit.layoutManager = LinearLayoutManager(this)
                adapter = PassengerTripListAdapter(this, Listdata,this)
                binding.rvtriplit.adapter = adapter

////                userPref.setUserId(it!!.data!!.Id.toString())
//                val intent = Intent(this, DashboardActivity::class.java)
//                startActivity(intent)
//                finish()
            } else {
//                toast(.message)
            }
        }
        viewModel.DeleteTRipComplete.observe(this) {
            if (it?.status == 1) {
                viewModel.TriplistApi(
                    "Bearer "+ userPref.getToken().toString(),
                )

            } else {
            }

        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
    }

    override fun tripdelete(id: String) {
        viewModel.DeleteTripHistory(
            "Bearer "+ userPref.getToken().toString(),id
        )
    }
}