package com.transportationapp.model

data class AddTripDriverMOdelClass(
    val `data`: AddTripDriverData,
    val message: String,
    val name: Name,
    val status: Int
)

data class AddTripDriverData(
    val body_name: String,
    val no_of_tyers: String,
    val pickup_lat: String,
    val vehicle_category: Any,
    val vehicle_name: String,
    val vehicle_number: String,
    val vehicle_type: String,
    val load_caring: String
)

data class Name(
    val driver_name: String
)