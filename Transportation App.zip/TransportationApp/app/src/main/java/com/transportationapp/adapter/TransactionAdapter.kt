package com.transportationapp.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.transportationapp.R
import com.transportationapp.databinding.RowWalletListBinding
import com.transportationapp.model.TransactionReportResponseData

class TransactionAdapter (val context: Context, val list : ArrayList<TransactionReportResponseData>):
    RecyclerView.Adapter<TransactionAdapter.ViewHolder>() {
    private var listener: TransactionAdapter.OnItemClickListener? = null


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.row_wallet_list, parent, false)
        return ViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val data = list[position]
        holder.binding.tvAmount.text = data.fare.toString()
        holder.binding.tvDate.text = data.booking_date.toString()
        holder.binding.tvDetail.text = "You have received Rs.${data.fare} from Abhay Sharma."

    }

    override fun getItemCount(): Int {
        return list.size
    }

    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: RowWalletListBinding = DataBindingUtil.bind(itemView)!!

    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.listener = listener

    }

    interface OnItemClickListener {
        fun onItemClick(position: Int, view: View)
    }

}