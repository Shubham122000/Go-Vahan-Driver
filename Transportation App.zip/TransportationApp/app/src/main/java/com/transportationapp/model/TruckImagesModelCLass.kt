package com.transportationapp.model

 data class TruckImagesModelCLass(
    var `data`: ArrayList<TruckImagesData>,
    var message: String,
    var status: Int
)

data class TruckImagesData(
    var image: String
)