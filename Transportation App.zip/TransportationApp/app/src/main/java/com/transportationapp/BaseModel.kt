package com.transportationapp

import androidx.databinding.BaseObservable
import java.io.Serializable

open class BaseModel : BaseObservable(), Serializable {
}