package com.transportationapp.ui.common

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.transportationapp.R
import com.transportationapp.adapter.OngoingTripAdapter
import com.transportationapp.adapter.UpcomingBookingsAdapter
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityUpcomingBookingsBinding
import com.transportationapp.model.TripHistoryResponseData
import com.transportationapp.utils.toast
import com.transportationapp.viewmodel.TripHistoryViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.util.*

@AndroidEntryPoint
class UpcomingBookings : BaseActivity() {
    private lateinit var binding : ActivityUpcomingBookingsBinding
    private val viewModel: TripHistoryViewModel by viewModels()
    var Listdata:ArrayList<TripHistoryResponseData> = ArrayList()
    lateinit var adapter : UpcomingBookingsAdapter
    var flag:String ="upcomingloader"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_upcoming_bookings)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_upcoming_bookings)

        binding.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.UpComingsTripHistoryApi(
            "Bearer "+ userPref.getToken().toString(),
        )
        viewModel.TripHistoryResponse.observe(this) {
            if (it?.status == 1) {
                Listdata.clear()
                Listdata.addAll(it.data)
                binding.rvUpcomingbookings.layoutManager = LinearLayoutManager(this)
                adapter = UpcomingBookingsAdapter(this, Listdata,flag)
                binding.rvUpcomingbookings.adapter =adapter
            } else {
                toast(it.message)
            }
        }
    }
}