package com.transportationapp.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.transportationapp.model.*
import com.transportationapp.network.MainRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class WalletViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel()  {
    val progressBarStatus = MutableLiveData<Boolean>()
    val walletListResponse = MutableLiveData<WalletListResponse>()
    val walletListfilterResponse = MutableLiveData<WalletFilterLIstREsponse>()
    val walletDownload = MutableLiveData<ProfileResponse>()
    val TransactionReportResponse = MutableLiveData<TransactionReportResponse>()
    val AddwalletResponse = MutableLiveData<Addmoneywallet>()
    val addmoneytowalletresponse = MutableLiveData<DriverProfile>()


    fun WalletListApi(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.WalletList(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                walletListResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }
    fun my_wallet_payment(
        token: String,
        type: String,
        transaction_id: String,
        amount: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.my_wallet_payment(token,type,transaction_id,amount)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                addmoneytowalletresponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }
    fun add_bank_account(
        token: String,
        account_no: String,
        name: String,
        ifsc: String,
        bank_name: String,
        account_branch: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.add_bank_account(token,account_no,name,ifsc,bank_name,account_branch)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                addmoneytowalletresponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun TransactionReport(
        token: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.TransactionReport(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                TransactionReportResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun addmoneywalletapi(
        token: String,
        amount:String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.Addmoneywallet(token,amount)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                AddwalletResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }
    fun Filteredwalletapi(
        token: String,
        date:String,transaction_type:String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.Filteredwallet(token,date,transaction_type)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                walletListfilterResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }

    fun my_driver_wallet_list_donload(
        token: String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.my_driver_wallet_list_donload(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                walletDownload.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }



}