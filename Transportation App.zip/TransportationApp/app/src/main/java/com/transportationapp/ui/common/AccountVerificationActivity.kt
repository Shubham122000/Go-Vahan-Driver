package com.transportationapp.ui.common

import android.Manifest
import android.annotation.SuppressLint
import android.content.CursorLoader
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import androidx.databinding.DataBindingUtil
import com.karumi.dexter.Dexter
import com.karumi.dexter.MultiplePermissionsReport
import com.karumi.dexter.PermissionToken
import com.karumi.dexter.listener.multi.MultiplePermissionsListener
import com.transportationapp.R
import com.transportationapp.viewmodel.LoginViewModel
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityAccountVerificationBinding
import com.transportationapp.utils.toast
import dagger.hilt.android.AndroidEntryPoint
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

@AndroidEntryPoint
class AccountVerificationActivity : BaseActivity(), View.OnClickListener {
    private val mLoginViewModel: LoginViewModel by viewModels()
    private lateinit var binding:ActivityAccountVerificationBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_account_verification)

        binding.btnNext.setOnClickListener(this)
        binding.ivBack.setOnClickListener(this)

        mLoginViewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        mLoginViewModel.accountVerificationResponse.observe(this) {
            if (it.status == 1) {
                Toast.makeText(this, "OTP Sent Successfully...${it.otp}", Toast.LENGTH_LONG).show()
//                userPref.user = it.data!!
//                userPref.isLogin = true
                val intent = Intent(this, OTPActivity :: class.java)
                intent.putExtra("id", it.data!!.id.toString())
                intent.putExtra("otp", it.data!!.otp)
                intent.putExtra("mobile_number", binding.etMobile.text.toString())
                startActivity(intent)
                finishAffinity()
            } else {
                toast(it.message)
            }
        }
    }
    override fun onClick(p0: View?) {
        when(p0?.id){
            R.id.btn_next ->{
                if(binding.etMobile.text.toString().isNullOrEmpty()){
                    snackbar("Please enter mobile number.")
                }else if (binding.etMobile.text.toString().length<10){
                    snackbar("Please enter valid mobile number.")
                }else {
                    mLoginViewModel.driverSendOtp(
                        binding.etMobile.text.toString(),
                        )
                }
            }
            R.id.ivBack ->{
                onBackPressed()
            }


        }
    }


}