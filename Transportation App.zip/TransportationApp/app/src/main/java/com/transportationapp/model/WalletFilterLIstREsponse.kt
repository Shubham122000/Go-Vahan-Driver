package com.transportationapp.model

data class WalletFilterLIstREsponse(
    var TotalAmount: TotalAmount,
    var `data`: List<WalletFilterLIstData>,
    var message: String,
    var status: Int
)

data class TotalAmount(
    var Total_amount: Int
)

data class WalletFilterLIstData(
    var amount: String,
    var credit: String,
    var name: String,
    var transaction_date: String
)