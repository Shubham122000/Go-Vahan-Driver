package com.transportationapp.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.transportationapp.model.AddDriverResponse
import com.transportationapp.model.FareCaluculationResponse
import com.transportationapp.model.SubscriptionPlan
import com.transportationapp.network.MainRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import retrofit2.http.Field
import javax.inject.Inject

@HiltViewModel
class SubscriptionPlanViewModel @Inject constructor(private val mainRepository: MainRepository) : ViewModel()  {

    val subscriptionPlan= MutableLiveData<SubscriptionPlan> ()
    val subscriptionPlanPayment= MutableLiveData<AddDriverResponse> ()
    val progressBarStatus = MutableLiveData<Boolean>()

    fun SubscriptionApi(
        token:String
    ){
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.subscriptionplan(token)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                subscriptionPlan.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }
    fun PaymentSubscriptionPlan(
        token: String,
        id: String,
        subscribe: String,
        fare: String,
        payment_mode: String,
        transaction_id: String,

        ){
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.loader_vehicle_payment(token,
                    id,
                    subscribe,
                    fare,
                    payment_mode,
                    transaction_id
                )
            if (response.isSuccessful) {
                progressBarStatus.value = false
                subscriptionPlanPayment.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun paymentsSubscriptionPassenger(
        token: String,
        id: String,
        subscribe: String,
        fare: String,
        payment_mode: String,
        transaction_id: String,
    ){
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.add_passenger_vehicle_payment(token,
                    id,
                    subscribe,
                    fare,
                    payment_mode,
                    transaction_id
                    )
            if (response.isSuccessful) {
                progressBarStatus.value = false
                subscriptionPlanPayment.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }



}