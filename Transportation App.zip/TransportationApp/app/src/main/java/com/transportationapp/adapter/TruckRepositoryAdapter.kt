package com.transportationapp.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.transportationapp.R
import com.transportationapp.customclick.loadervehiclelist
import com.transportationapp.customclick.tripdelete

import com.transportationapp.databinding.UiRowTruckRepositoryBinding
import com.transportationapp.model.LoaderTruckRepositoryListResponseData


class TruckRepositoryAdapter (val context : Context, val list: List<LoaderTruckRepositoryListResponseData>,var deletevehicle:tripdelete,var loadervehiclelist: loadervehiclelist) : RecyclerView.Adapter<TruckRepositoryAdapter.ViewHolder>() {
    private var listener: OnItemClickListener? = null


    inner  class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        var binding: UiRowTruckRepositoryBinding = DataBindingUtil.bind(itemView)!!
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.ui_row_truck_repository, parent, false)
        return ViewHolder(itemView)    }

    @SuppressLint("SetTextI18n")
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val data = list[position]

        if (data.status.equals("1")){
            holder.binding.status.text="Payment Pending"
        }else if(data.status.equals("0")){
            holder.binding.status.text="Under reviewed"

        }else if(data.status.equals("2")){
            holder.binding.status.text="Completed"
        }

        holder.binding.tvTrucknumber.text = data.loaderNumber
        holder.binding.tvTruckname.text = data.loaderName
        holder.binding.tvOwnername.text  = data.owner_name
        Glide.with(context).load(data.image).into(holder.binding.ivVehicle)
        holder.binding.delete.setOnClickListener {
            deletevehicle.tripdelete(data.vehicleId.toString())
        }





         holder.binding.linearItem.setOnClickListener {
        loadervehiclelist.loadervehiclelist(data.vehicleId.toString())
        }


    }

    override fun getItemCount(): Int {

        return list.size
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        this.listener = listener

    }

    interface OnItemClickListener {
        fun onItemClick(position: Int, view: View)
    }


}