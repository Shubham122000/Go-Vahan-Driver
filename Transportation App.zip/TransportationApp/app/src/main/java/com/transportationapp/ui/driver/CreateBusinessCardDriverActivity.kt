package com.transportationapp.ui.driver

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.transportationapp.R

class CreateBusinessCardDriverActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_business_card_driver)
    }
}