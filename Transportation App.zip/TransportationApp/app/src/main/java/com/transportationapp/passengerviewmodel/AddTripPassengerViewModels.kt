package com.transportationapp.passengerviewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.transportationapp.model.*
import com.transportationapp.network.MainRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import javax.inject.Inject

@HiltViewModel
class AddTripPassengerViewModels @Inject constructor(private val mainRepository: MainRepository) : ViewModel() {

    val progressBarStatus = MutableLiveData<Boolean>()
    val _progressBarVisibility = MutableLiveData<Int>()
    var AddTripResponse = MutableLiveData<CreateBusinesscard>()
    var LoadcarryingResponse = MutableLiveData<LoaodCarryingResponse>()
    var LoadCarryingData = MutableLiveData<ArrayList<LoadCarryingData>>()
    var truckTypeResponse = MutableLiveData<TypeofTruckResponse>()
    var truckTypeData = MutableLiveData<ArrayList<TypeofTruckResponseData>>()
    var BodyTypeResponse = MutableLiveData<BodyType>()
    var SeatResponse = MutableLiveData<SeatResponse>()
    var SeatResponseData = MutableLiveData<ArrayList<SeatResponseData>>()
    var VehicalwheelsResponse = MutableLiveData<vehicalwheelsResponse>()
    val DriverlistResponse = MutableLiveData<DriverListResponse>()
    val DriverlistResponseData = MutableLiveData<ArrayList<DriverListResponseData>>()
    var VehicleListResponse = MutableLiveData<VehicleList>()
    var VehicleListResponseData = MutableLiveData<ArrayList<VehicleListData>>()
    var BodyTypeData = MutableLiveData<ArrayList<BodyTypeData>>()
    var VehicalwheelsData = MutableLiveData<ArrayList<vehicalwheelsResponseData>>()
    var HightTypeResponse = MutableLiveData<hightResponse>()
    var HeightTypeData = MutableLiveData<ArrayList<hightResponseData>>()
    var ColorResponse = MutableLiveData<ColorResponse>()
    var YearResponse = MutableLiveData<YearResponse>()
    var Colordata = MutableLiveData<ArrayList<ColorResponseData>>()
    var Yearresponsedata = MutableLiveData<ArrayList<YearResponseData>>()
    var AddpassengerResponse = MutableLiveData<AddloaderResponse>()
    var AddloaderResponse = MutableLiveData<AddloaderResponse>()
    var Loaderimage = MutableLiveData<Loaderimage>()
    var AddVehicalfinalResponse = MutableLiveData<AddVehicalfinalResponse>()
    var VehiclenumberResponse = MutableLiveData<VehicleNumberPassengerLIst>()
    var VehiclenumberData = MutableLiveData<ArrayList<VehicleNumberData>>()
    var addpassengerLoaderResponse = MutableLiveData<ArrayList<VehicleNumberData>>()
    var AddTripDriverMOdelClass = MutableLiveData<AddTripDriverMOdelClass>()


    fun Color(token :String): MutableLiveData<ColorResponse> {
        if (ColorResponse == null) {
            ColorResponse = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.ColorApi(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    ColorResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return ColorResponse
    }

    fun Year(token :String): MutableLiveData<YearResponse> {
        if (YearResponse == null) {
            YearResponse = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.YearApi(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    YearResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return YearResponse
    }
    fun HightType(token :String): MutableLiveData<hightResponse> {
        if (HightTypeResponse == null) {
            HightTypeResponse = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.HightApi(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    HightTypeResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return HightTypeResponse
    }


    fun CapacityAPI(token :String): MutableLiveData<LoaodCarryingResponse> {
        if (LoadcarryingResponse == null) {
            LoadcarryingResponse = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.CapacityApi(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    LoadcarryingResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return LoadcarryingResponse
    }
    fun VehicleList(token :String): MutableLiveData<VehicleList> {
        if (VehicleListResponse == null) {
            VehicleListResponse = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.GetVehicle(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    VehicleListResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return VehicleListResponse
    }
    fun VehicleNumberLIst(token :String): MutableLiveData<VehicleNumberPassengerLIst> {
        if (VehiclenumberResponse == null) {
            VehiclenumberResponse = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.get_passenger_vehicleno(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    VehiclenumberResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return VehiclenumberResponse
    }


    fun TypeofTruckApi(token :String): MutableLiveData<TypeofTruckResponse> {
        if (truckTypeResponse == null) {
            truckTypeResponse = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.TypeofTruckApi(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    truckTypeResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return truckTypeResponse
    }

    fun BodyType(token :String): MutableLiveData<BodyType> {
        if (BodyTypeResponse == null) {
            BodyTypeResponse = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.BodyTypeApi(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    BodyTypeResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return BodyTypeResponse
    }
    fun self_driver_passenger_trip(token :String): MutableLiveData<AddTripDriverMOdelClass> {
        if (AddTripDriverMOdelClass == null) {
            AddTripDriverMOdelClass = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.self_driver_passenger_trip(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    AddTripDriverMOdelClass.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return AddTripDriverMOdelClass
    }

    fun SeatAPI(token :String): MutableLiveData<SeatResponse> {
        if (SeatResponse == null) {
            SeatResponse = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.vehicleSeat(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    SeatResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return SeatResponse
    }
    fun Vehicalwheels(token :String): MutableLiveData<vehicalwheelsResponse> {
        if (VehicalwheelsResponse == null) {
            VehicalwheelsResponse = MutableLiveData()
        }
        viewModelScope.launch {
            try {
                val response = mainRepository.vehicalwheels(token)

                if (response.isSuccessful) {
                    progressBarStatus.value = false
                    VehicalwheelsResponse.postValue(response.body())
                }
            }catch (e:Exception) {
                _progressBarVisibility.postValue(0)
                e.printStackTrace()
            }
        }
        return VehicalwheelsResponse
    }

    fun driverListApi(
        token: String,
        vendor_id: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.driverList(token, vendor_id)
            if (response.isSuccessful) {
                progressBarStatus.value = false
                DriverlistResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }



    fun PassengerimageAPI(
        token :String,
        vehicle_id:String,
        Image: MultipartBody.Part?
    ) {
        val vehicle_id: RequestBody = vehicle_id.toRequestBody("text/plain".toMediaTypeOrNull())
        progressBarStatus.value = true
        viewModelScope.launch {

            val response = mainRepository.passengerVehicleimg(
                token,
                vehicle_id,
                Image!!
            )
            if (response.isSuccessful) {
                progressBarStatus.value = false
                Loaderimage.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }


    fun AddpassengerVehicalfinalApi(
        token: String,
        driver_id: String,
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {
            val response = mainRepository.FinalpassengervehicalSubmit(token,driver_id)
            if (response.isSuccessful) {

                progressBarStatus.value = false
                Log.d("TAG", "success")
                AddVehicalfinalResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", "Failed")
            }
        }
    }



    fun PassengerdocAPI(
        token :String,
        vehicle_id:String,
        doc_name:String,
        Doc: MultipartBody.Part?
    ) {
        val vehicle_id: RequestBody = vehicle_id.toRequestBody("text/plain".toMediaTypeOrNull())
        val doc_name: RequestBody = doc_name.toRequestBody("text/plain".toMediaTypeOrNull())
        progressBarStatus.value = true
        viewModelScope.launch {

            val response = mainRepository.Passengervehicledoc(
                token,
                vehicle_id,
                doc_name,
                Doc!!
            )
            if (response.isSuccessful) {
                progressBarStatus.value = false
                Loaderimage.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }
    }



    fun AddTripApi(
        token: String,
        tip_task: String,
        load_caring: String,
        from_trip: String,
        to_trip: String,
        vehicle_type: String,
        vehicle_numbers: String,
        no_tyers: String,
        body_type: String,
        assign_driver: String,
        total_distance: String,
        freight_amount: String,
        pickup_lat: String,
        pickup_long: String,
        dropup_lat: String,
        dropup_long: String,
        vehicle_id: String,
        booking_date_from: String,
        booking_time: String,

        ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.AddTripPassenger(
                    token,
                    tip_task,
                    load_caring,
                    from_trip,
                    to_trip,
                    vehicle_type,
                    vehicle_numbers,
                    no_tyers,
                    body_type,
                    assign_driver,
                    total_distance,
                    freight_amount,
                    pickup_lat,
                    pickup_long,
                    dropup_lat,
                    dropup_long,
                    vehicle_id,
                    booking_date_from,
                    booking_time
                )
            if (response.isSuccessful) {
                progressBarStatus.value = false
                AddTripResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

    fun Addpassengervehical(
        token: String,
        driver_id: String,
        vehicle_owner_name: String,
        vehicle_name: String,
        year_of_model: String,
        vehicle_number: String,
        vehicle_type: String,
//        vehicle_category: String,
        capacity: String,
        height: String,
        color: String,
        no_of_tyres: String,
        body_type: String,
        seat:String
    ) {
        progressBarStatus.value = true
        viewModelScope.launch {

            val response =
                mainRepository.addpassengervehical(
                    token,
                    driver_id,
                    vehicle_owner_name,
                    vehicle_name,
                    year_of_model,
                    vehicle_number,
                    vehicle_type,
//                    vehicle_category,
                    capacity,
                    height,
                    color,
                    no_of_tyres,
                    body_type,
                    seat
                )
            if (response.isSuccessful) {
                progressBarStatus.value = false
                AddloaderResponse.postValue(response.body())
            } else {
                progressBarStatus.value = false
                Log.d("TAG", response.body().toString())
            }
        }

    }

}