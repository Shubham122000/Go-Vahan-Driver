package com.transportationapp.model

import com.google.gson.annotations.SerializedName


data class WalletListResponse(
    var TotalAmount: TotalAmount,
    var `data`: List<WalletListData>,
    var message: String,
    var status: Int
)

data class WalletListData(
    var amount: String,
    var credit: String,
    var name: String,
    var debit:String,
    var transaction_date: String
)