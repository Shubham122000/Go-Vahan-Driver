package com.transportationapp.model

import com.google.gson.annotations.SerializedName

class Addmoneywallet {
    @SerializedName("status"      ) var status      : Int?            = null
    @SerializedName("message"     ) var message     : String?         = null
}