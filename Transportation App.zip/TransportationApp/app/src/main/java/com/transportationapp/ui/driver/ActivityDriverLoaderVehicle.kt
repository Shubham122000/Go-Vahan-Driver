package com.transportationapp.ui.driver

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.transportationapp.R
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityDriverLoaderVehicleBinding
import com.transportationapp.ui.AddDriverActivity
import com.transportationapp.ui.common.AddTruckDocumentsActivity
import com.transportationapp.ui.driver.passenger.AddTripLoaderDriver
import com.transportationapp.ui.driver.passenger.AddTripPassengerDriver
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ActivityDriverLoaderVehicle : BaseActivity() {

    private lateinit var binding : ActivityDriverLoaderVehicleBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        //setContentView(R.layout.activity_loader_vehicle)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_driver_loader_vehicle)


        binding.ivBack.setOnClickListener(View.OnClickListener {
            finish()

        })



        binding.llAddtrip.setOnClickListener(View.OnClickListener {
            if (userPref.getusertype().equals("3")){
                val intent = Intent(this, AddTripActivity::class.java)
                startActivity(intent)
            }
            else{
                val intent = Intent(this, AddTripLoaderDriver::class.java)
                startActivity(intent)
            }


        })

        binding.llAdddriver.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, AddDriverActivity::class.java)
            startActivity(intent)

        })


        binding.llTruckdocument.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, AddTruckDocumentsActivity::class.java)
            startActivity(intent)

        })




    }
}