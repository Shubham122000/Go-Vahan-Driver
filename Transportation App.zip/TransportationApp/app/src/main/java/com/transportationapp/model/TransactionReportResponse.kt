package com.transportationapp.model

import com.google.gson.annotations.SerializedName

data class TransactionReportResponse(
    @SerializedName("status"      ) var status      : Int?            = null,
    @SerializedName("message"     ) var message     : String?         = null,
    @SerializedName("data"        ) var data        : ArrayList<TransactionReportResponseData> = arrayListOf(),
)
data class TransactionReportResponseData(
    @SerializedName("fare"               ) var fare              : Int?    = null,
    @SerializedName("booking_date"       ) var booking_date      : String?    = null,
)
