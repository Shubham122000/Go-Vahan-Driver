package com.transportationapp.ui

import android.os.Bundle
import android.view.View
import androidx.databinding.DataBindingUtil
import com.transportationapp.R
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityCreateBusinessCard2Binding

class CreateBusinessCard2 : BaseActivity() {

    private lateinit var binding : ActivityCreateBusinessCard2Binding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_create_business_card2)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_create_business_card2)

        binding.btnDownload.setOnClickListener(View.OnClickListener {
            /*val intent = Intent(this, AddDriverActivity::class.java)
            startActivity(intent)*/

        })


    }
}