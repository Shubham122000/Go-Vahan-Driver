package com.transportationapp.ui

import android.os.Bundle
import androidx.databinding.DataBindingUtil
import com.transportationapp.R
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityEditProfileBinding
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class EditProfileActivity : BaseActivity() {
    private lateinit var binding : ActivityEditProfileBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_edit_profile)

    }
}