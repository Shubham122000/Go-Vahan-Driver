package com.transportationapp.model

data class DashboardMenuModel(val title : String){


}
