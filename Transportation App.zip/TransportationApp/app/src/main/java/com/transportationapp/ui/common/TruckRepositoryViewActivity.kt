package com.transportationapp.ui.common

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.transportationapp.R
import com.transportationapp.adapter.TruckDocumentsAdapter
import com.transportationapp.adapter.TruckImagesAdapter
import com.transportationapp.base.BaseActivity
import com.transportationapp.customclick.click
import com.transportationapp.databinding.ActivityTruckRepositoryViewBinding
import com.transportationapp.model.*
import com.transportationapp.ui.vendor.VendorsSubscriptionPlanActivity
import com.transportationapp.utils.toast
import com.transportationapp.viewmodel.TruckRepositoryViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TruckRepositoryViewActivity : BaseActivity() ,click{
    private lateinit var binding : ActivityTruckRepositoryViewBinding
    private val viewModel: TruckRepositoryViewModel by viewModels()
    var Listdata:ArrayList<TruckImagesData> = ArrayList()
    var Listdata1:ArrayList<TruckDocumentsData> = ArrayList()
    var newurl :String = ""
    var downlloadpdf :String = ""
    var url :String =""

    lateinit var adapter : TruckImagesAdapter
    lateinit var adapter1 : TruckDocumentsAdapter
    var vehicle_id=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_truck_repository_view)


        if (intent!=null){
            vehicle_id= intent.getStringExtra("vehicle_id").toString()
        }
        binding.btn.setOnClickListener {
            val intent =  Intent(this, VendorsSubscriptionPlanActivity::class.java).putExtra("vehicle_id", vehicle_id).putExtra("flag1","loader")
            startActivity(intent)
        }
        binding.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.loader_truck_repository_list_details(
            "Bearer "+ userPref.getToken().toString(),vehicle_id
        )
        viewModel.truckviewResponse.observe(this) {
            if (it?.status == 1) {
                binding.etTruckownername.text=it.data.owner_name
                binding.spinnerTrucktype.text=it.data.loader_name
                binding.etVehivalnumber.text=it.data.loader_number
//                binding.etCapacity.text=it.data.capacity
//                binding.spinnerHeight.text=it.data.height
                binding.spinnerTyrenumber.text= it.data.tyres.toString()
                binding.spinnerBadytype.text=it.data.bodyname
                binding.spinnerYearofmodel.text=it.data.year.toString()
                if (it.data.status==1){
                    binding.btn.visibility=View.VISIBLE
                    binding.btn.text="Proceed Payment"
                }
                else{
                    binding.btn.visibility= View.GONE

                }

            } else {
                toast(it.message)
            }
        }
        viewModel.loader_truck_repository_image_list_details(
            "Bearer "+ userPref.getToken().toString(),vehicle_id
        )
        viewModel.loader_truck_repository_documents(
            "Bearer "+ userPref.getToken().toString(),vehicle_id
        )
        viewModel.truckImagesResponse.observe(this) {
            if (it?.status == 1) {
                Listdata.clear()
                Listdata.addAll(it.data)

                binding.rvImages.layoutManager = GridLayoutManager(this,2)
                adapter = TruckImagesAdapter(this, Listdata)
                binding.rvImages.adapter =adapter
            } else {
                //toast(it.message)
                snackbar(it?.message!!)
            }
        }
        viewModel.truckDocumentsResponse.observe(this) {
            if (it?.status == 1) {
                Listdata1.clear()
                Listdata1.addAll(it.data)

                binding.rvDocuments.layoutManager = LinearLayoutManager(this)
                adapter1 = TruckDocumentsAdapter(this, Listdata1,this)
                binding.rvDocuments.adapter =adapter1
            } else {
                snackbar(it?.message!!)
            }
        }
    }

    override fun Click(position: Int,url:String) {

            val i = Intent(Intent.ACTION_VIEW)
            i.data = Uri.parse(url)
            startActivity(i)


//        val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(newurl))
//        startActivity(browserIntent)

//        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(newurl)))
        downlloadpdf = url
        var urlsplit = downlloadpdf.split("/public")!!.toTypedArray()

        var url1 = urlsplit[0]
        var url2 = urlsplit[1]
        newurl = url1+url2
    }
}