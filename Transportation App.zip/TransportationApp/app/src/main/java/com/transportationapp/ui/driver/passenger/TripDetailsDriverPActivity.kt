package com.transportationapp.ui.driver.passenger

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.transportationapp.R

class TripDetailsDriverPActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trip_details_driver_pactivity)
    }
}