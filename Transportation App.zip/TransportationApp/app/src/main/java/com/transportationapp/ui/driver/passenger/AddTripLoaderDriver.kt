package com.transportationapp.ui.driver.passenger

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.TimePicker
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.google.android.gms.maps.model.LatLng
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.android.libraries.places.widget.Autocomplete
import com.google.android.libraries.places.widget.AutocompleteActivity
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode
import com.google.maps.android.SphericalUtil
import com.transportationapp.R
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityAddTripLoaderDriverBinding
import com.transportationapp.databinding.ActivityAddTripVactivityBinding
import com.transportationapp.model.*
import com.transportationapp.utils.toast
import com.transportationapp.viewmodel.TypeOfTruckViewModel
import java.util.*
import kotlin.collections.ArrayList

class AddTripLoaderDriver : BaseActivity() {
    private lateinit var binding : ActivityAddTripLoaderDriverBinding
    private val viewModel : TypeOfTruckViewModel by viewModels()

    var datePicker: DatePickerDialog? = null
    var truckdata : ArrayList<TypeofTruckResponseData> = ArrayList()
    var wheels : ArrayList<vehicalwheelsResponseData> = ArrayList()
    var vehicle :ArrayList<VehicleListData> = ArrayList()
    var vehiclenumber :ArrayList<VehicleNumberListData> = ArrayList()
    var Vehicletype :ArrayList<String> = ArrayList()
    var VehicleIDtype :ArrayList<String> = ArrayList()
    var vehicle_number: ArrayList<String> = ArrayList()
    var nametype :ArrayList<String> = ArrayList()
    var vehicalwheel :ArrayList<String> = ArrayList()
    var Capacity : ArrayList<LoadCarryingData> = ArrayList()
    var Capacitytype :ArrayList<String> = ArrayList()
    var id_Capacity :ArrayList<String> = ArrayList()
    var id_type :ArrayList<String> = ArrayList()
    var id_wheels :ArrayList<String> = ArrayList()
    var Bodydata : ArrayList<BodyTypeData> = ArrayList()
    var Bodytype :ArrayList<String> = ArrayList()
    var id_body :ArrayList<String> = ArrayList()
    var tripvalue=""
    var assigneddriver :ArrayList<DriverListResponseData> = ArrayList()
    var driver :ArrayList<String> = ArrayList()
    var id_driver :ArrayList<String> = ArrayList()
    var value=""
    var selectedTruckTypeId=""
    var selectedCapacityId=""
    var selectedWheelsId=""
    var selectedBodyId=""
    var selecteddriverId=""
    var selectedVehicleName=""
    var selectedVehicleNumber=""

    // Google Place API Variables

    var placesClient: PlacesClient? = null
    private val AUTOCOMPLETE_FROM_REQUEST_CODE = 1
    private val AUTOCOMPLETE_TO_REQUEST_CODE = 2

    var latLng: LatLng? = null
    var pickupLongitude = 0.0
    var pickupLatitude = 0.0
    var dropLongitude = 0.0
    var dropLatitude = 0.0
    var sourceLatLong: LatLng? = null
    var destLatLong: LatLng? = null
    var distance: Double? = null
    var  distanceString: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_add_trip_loader_driver)

        binding.ivBack.setOnClickListener(View.OnClickListener {
            finish()
        })
        binding.lltextdate.setOnClickListener {
            Selectdate()
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.AddTripResponse.observe(this) {
            if (it?.status == 1) {
              toast("Trip Successfully Added")
                finish()
            } else {
                //toast(it.message)
                snackbar(it?.message!!)
            }
        }
        val apiKey = getString(R.string.api_key)
        if (!Places.isInitialized()) {
            Places.initialize(this, apiKey)
        }
        placesClient = Places.createClient(this)
        binding.etFrom.setOnClickListener {
            placesAPiCall(AUTOCOMPLETE_FROM_REQUEST_CODE)
        }
        binding.etTo.setOnClickListener {
            placesAPiCall(AUTOCOMPLETE_TO_REQUEST_CODE)
        }


        viewModel.TripLoaderDriver(
            "Bearer "+userPref.getToken().toString(),
        ).observe(this) {

            if (it!!.status == 1) {
                binding.driverassign.text=it.name.driver_name
                binding.spinnerLoadcarring.text="${it.data.load_caring} Ton"
                    binding.spinnerVehiclename.text=it.data.vehicle_name
                    binding.spinnerVehicletype.text=it.data.vehicle_type
                    binding.spinnerVehiclenumber.text=it.data.vehicle_number
                    binding.spinnerNooftyres.text=it.data.no_of_tyers
                    binding.spinnerBodytype.text=it.data.body_name

            }
        }



        binding.btnAddthistrip.setOnClickListener {

            if (binding.etTriptask.text.toString().isEmpty()){
                toast("Please enter trip Task.")
            }else if (binding.etFrom.text.toString().isEmpty()){
                toast("Please enter from location.")
            }else if (binding.etTo.text.toString().isEmpty()){
                toast("Please enter to location.")
            }



            else if (binding.etPrice.text.toString().isEmpty()){
                toast("Please enter amount.")
            }

            else if (binding.spinnerTimeslots.selectedItem.equals("Select Time Slots")){
                toast("Please select time slot.")
            }

            else{



                viewModel.AddTripApi(
                    "Bearer "+userPref.getToken().toString(),
                    binding.etTriptask.text.toString(),
                    binding.spinnerLoadcarring.text.toString(),
                    binding.etFrom.text.toString(),
                    binding.etTo.text.toString(),
                  binding.spinnerVehicletype.text.toString(),
                    binding.spinnerVehiclenumber.text.toString(),
                    binding.spinnerNooftyres.text.toString(),
                    binding.spinnerBodytype.text.toString(),
                    binding.driverassign.text.toString(),
                    distanceString.toString(),
                    binding.etPrice.text.toString(),
                    pickupLatitude.toString(),
                    pickupLongitude.toString(),
                    dropLatitude.toString(),
                    dropLongitude.toString(),
                    binding.spinnerVehiclename.text.toString(),
                    binding.tvDate.text.toString(),
                    binding.spinnerTimeslots.selectedItem.toString(),
                )
            }
        }

    }
    private fun placesAPiCall(requestCode: Int) {
        val fields = listOf(
            Place.Field.ID,
            Place.Field.NAME,
            Place.Field.ADDRESS,
            Place.Field.LAT_LNG
        )
        val intent = Autocomplete.IntentBuilder(AutocompleteActivityMode.FULLSCREEN, fields)
            .build(this)
        startActivityForResult(intent, requestCode)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == AUTOCOMPLETE_FROM_REQUEST_CODE) {
            when (resultCode) {     //binding.etAmount.text = it.data!!.rate
                Activity.RESULT_OK -> {
                    val place = Autocomplete.getPlaceFromIntent(data!!)
                    Log.i("TAG", "Place: " + place.name + ", " + place.id)
                    latLng = place.latLng
                    pickupLongitude = latLng!!.longitude
                    pickupLatitude = latLng!!.latitude
                    binding.etFrom.text = place.name
                    sourceLatLong = LatLng(pickupLatitude, pickupLongitude)
                    Log.e("@@pickupLatitude", pickupLatitude.toString())
                }
                AutocompleteActivity.RESULT_ERROR -> {
                    val status = Autocomplete.getStatusFromIntent(data!!)
                    Log.i("TAG", status.statusMessage!!)
                }
                Activity.RESULT_CANCELED -> {
                }
            }
            return
        } else if (requestCode == AUTOCOMPLETE_TO_REQUEST_CODE) {
            when (resultCode) {
                Activity.RESULT_OK -> {
                    val place = Autocomplete.getPlaceFromIntent(data!!)
                    Log.i("TAG", "Place: " + place.name + ", " + place.id)
                    latLng = place.latLng
                    dropLongitude = latLng!!.longitude
                    dropLatitude = latLng!!.latitude
                    //  binding.moveFrom.text =  place.name
                    binding.etTo.text = place.name
                    destLatLong = LatLng(dropLatitude, dropLongitude)
                    distance = SphericalUtil.computeDistanceBetween(sourceLatLong, destLatLong)
                    fromMeterToKM(distance!!)
                }
                AutocompleteActivity.RESULT_ERROR -> {
                    val status = Autocomplete.getStatusFromIntent(data!!)
                    Log.i("TAG", status.statusMessage!!)
                }
                Activity.RESULT_CANCELED -> {
                    // The user canceled the operation.
                }
            }
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }
    fun Selectdate(){
        val myCalendar = Calendar.getInstance()
        var day = myCalendar.get(Calendar.DAY_OF_MONTH)
        var year = myCalendar.get(Calendar.YEAR)
        var month = myCalendar.get(Calendar.MONTH)
        datePicker = DatePickerDialog(this)
        datePicker = DatePickerDialog(
            this, R.style.DatePickerTheme,
            { view, year, month, dayOfMonth -> // adding the selected date in the edittext
//                    if (month < 10){
//                        if (dayOfMonth < 10){
//                            binding.Selectdate.setText("0"+dayOfMonth.toString() + "-" + "0"+(month + 1) + "-" + year)
//
//                        }else{
//                            binding.Selectdate.setText(dayOfMonth.toString() + "-" + "0"+(month + 1) + "-" + year)
//                        }
//                    }else{
//                        if (dayOfMonth < 10){
//                            binding.Selectdate.setText("0"+dayOfMonth.toString() + "-" +(month + 1) + "-" + year)
//
//                        }else{
//                            binding.Selectdate.setText(dayOfMonth.toString() + "-" +(month + 1) + "-" + year)
//                        }
//                    }
                binding.tvDate.setText(dayOfMonth.toString() + "-" + (month + 1) + "-" + year)
            }, year, month, day
        )
//            date  = DateFormat.proxyDateFormat(binding.Selectdate.text.toString()).toString()
        datePicker!!.getDatePicker().setMinDate(myCalendar.getTimeInMillis())
        // show the dialog
        datePicker!!.show()
    }
    fun fromMeterToKM(m: Double) {
        Log.e("@@1", (m / 1000).toInt().toString())
        distanceString = (m / 1000).toInt().toString()
    }
}