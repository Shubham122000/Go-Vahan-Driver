package com.transportationapp.ui.common

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.transportationapp.R
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityAddAccountBinding
import com.transportationapp.databinding.ActivityWalletBinding
import com.transportationapp.utils.toast
import com.transportationapp.viewmodel.WalletViewModel

class AddAccountActivity : BaseActivity() {
    private lateinit var binding : ActivityAddAccountBinding
    private val viewModel: WalletViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_add_account)


        binding.ivBack.setOnClickListener {
            finish()
        }
        binding.PaymentButton.setOnClickListener {


            if (binding.bankName.text.toString().equals("")) {
                toast("Please enter bank name.")
            } else if (binding.holdername.text.toString().equals("")) {
                toast("Please enter Account Holder's name.")
            } else if (binding.accountNumber.text.toString().equals("")) {
                toast("Please enter Account number.")
            } else if (binding.accountBranch.text.toString().equals("")) {
                toast("Please enter Account branch.")
            } else if (binding.ifscCode.text.toString().equals("")) {
                toast("Please enter IFSC.")
            } else {
                viewModel.add_bank_account(
                    "Bearer " + userPref.getToken().toString(),
                    binding.accountNumber.text.toString(),
                    binding.holdername.text.toString(),
                    binding.ifscCode.text.toString(),
                    binding.bankName.text.toString(),
                    binding.accountBranch.text.toString()
                )
            }
        }

        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.addmoneytowalletresponse.observe(this)
        {
            if (it.status == 1) {
                toast(it.message)
         finish()
            } else {
                toast(it.message!!)
            }
        }
    }




}