package com.transportationapp.adapter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.transportationapp.R
import com.transportationapp.customclick.SubscriptionPLanClick
import com.transportationapp.customclick.click
import com.transportationapp.databinding.TruckImagesItemsBinding
import com.transportationapp.databinding.TruckRepositoryDocumentItemsBinding
import com.transportationapp.model.TruckDocumentsData
import com.transportationapp.model.TruckImagesData
import com.transportationapp.ui.common.TripDetailsActivity


class TruckDocumentsAdapter  (var context: Context, var list: List<TruckDocumentsData>,var click: click)
    : RecyclerView.Adapter<TruckDocumentsAdapter.ViewHolder>() {
    var newurl :String = ""
    inner class ViewHolder(itemview: View) : RecyclerView.ViewHolder(itemview) {
//        var binding: TruckRepositoryDocumentItemsBinding = DataBindingUtil.bind(itemview)!!

        var tv_rcbook: TextView
        var fileDwnd: ImageView

        init {
            tv_rcbook = itemView.findViewById(R.id.tv_rcbook)
            fileDwnd = itemView.findViewById(R.id.file_dwnd)

        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemview =
            LayoutInflater.from(parent.context).inflate(R.layout.truck_repository_document_items, parent, false)
        return ViewHolder(itemview)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        var data = list[position]

        holder.tv_rcbook.text=data.doc_name

        holder.fileDwnd.setOnClickListener {
            click.Click(position,data.doc)

        }

    }



    override fun getItemCount(): Int {
        return list.size
    }
}