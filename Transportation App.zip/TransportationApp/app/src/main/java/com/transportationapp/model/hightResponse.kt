package com.transportationapp.model

import com.google.gson.annotations.SerializedName

data class hightResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<hightResponseData> = arrayListOf()
)

data class hightResponseData(
    @SerializedName("id"         ) var id        : Int?    = null,
    @SerializedName("height"     ) var height    : String? = null,
    @SerializedName("status"     ) var status    : Int?    = null,
    @SerializedName("created_at" ) var createdAt : String? = null,
    @SerializedName("updated_at" ) var updatedAt : String? = null
){
    override fun toString(): String {
        return height.toString()
    }
}
