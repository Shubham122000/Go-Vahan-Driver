package com.transportationapp.ui.common

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.content.res.AppCompatResources
import androidx.databinding.DataBindingUtil
import com.transportationapp.R
import com.transportationapp.viewmodel.LoginViewModel
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityLoginBinding
import com.transportationapp.ui.DashboardActivity
import com.transportationapp.ui.driver.SignupActivity
import com.transportationapp.utils.toast
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginActivity : BaseActivity(), View.OnClickListener {
    lateinit var binding: ActivityLoginBinding
    private val viewModel: LoginViewModel by viewModels()
    private var isVisible1 = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login)
        binding.lifecycleOwner = this
        binding.btnSignup.setOnClickListener(this)
        binding.lytVisiblePass.setOnClickListener(this)
        binding.tvForgotPass.setOnClickListener(this)
        binding.btnLogin.setOnClickListener(this)
        viewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.loginResponse.observe(this) {
            if (it?.status == 1) {
                Toast.makeText(this, "Logged in Successfully...", Toast.LENGTH_LONG).show()
                userPref.user = it.data!!
                userPref.isLogin = true
                userPref.setid(it.data?.id.toString())
                userPref.setToken(it.data!!.apiToken)
                userPref.setusertype(it.data!!.role.toString())
                userPref.setRole(it.data!!.role.toString())
                userPref.setName(it.data?.name!!)
                userPref.setEmail(it.data!!.email)
                userPref.setMobile(it.data!!.mobileNumber.toString())
                userPref.setUserId(it.data!!.id!!.toString())
                it.data!!.profileImage?.let { it1 -> userPref.setImage(it1) }
//                userPref.setUserId(it!!.data!!.Id.toString())
                val intent = Intent(this, DashboardActivity::class.java)
                startActivity(intent)
                finishAffinity()
            } else {
                //toast(it.message)
                snackbar(it?.message!!)
            }
        }
    }
    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.btn_signup -> {
                finish()
            }
            R.id.lytVisiblePass -> {
                if (isVisible1) {
                    binding.edtPassword.transformationMethod =
                        PasswordTransformationMethod.getInstance()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        binding.ivVisiblePass.setImageDrawable(
                            AppCompatResources.getDrawable(
                                this,
                                R.drawable.password_hide
                            )
                        )
                        binding.edtPassword.setSelection(binding.edtPassword.text.length)
                    }
                    isVisible1 = false
                } else { //Toast.makeText(this,"show",Toast.LENGTH_SHORT).show();
                    binding.edtPassword.transformationMethod =
                        HideReturnsTransformationMethod.getInstance()
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        binding.ivVisiblePass.setImageDrawable(
                            AppCompatResources.getDrawable(
                                this,
                                R.drawable.password_view
                            )
                        )
                        binding.edtPassword.setSelection(binding.edtPassword.text.length)
                    }
                    isVisible1 = true
                }
            }
            R.id.tvForgotPass -> {
                val intent = Intent(this, AccountVerificationActivity::class.java)
                startActivity(intent)
            }
            R.id.btn_login -> {
                if (binding.edtEmailLogin.text.toString().isNullOrEmpty()
                ) {
                    toast("Please enter Username.")
                } else if (binding.edtPassword.text.toString().isNullOrEmpty()) {
                    toast(" password field at least must have entered one capital letter, one special character, and varchar values and password length should be minimum of 6 letters")
                } else {
                    viewModel.driverLogin(
                        binding.edtEmailLogin.text.toString(),
                        binding.edtPassword.text.toString(),
                        "Android",
                        "Android"
                    )
                }
            }
        }
    }
}


