package com.transportationapp.model

import com.google.gson.annotations.SerializedName

data class YearResponse(
    @SerializedName("status"  ) var status  : Int?            = null,
    @SerializedName("message" ) var message : String?         = null,
    @SerializedName("data"    ) var data    : ArrayList<YearResponseData> = arrayListOf()
)

data class YearResponseData(
    @SerializedName("id"         ) var id        : Int?    = null,
    @SerializedName("model"      ) var model     : String? = null,
    @SerializedName("status"     ) var status    : Int?    = null,
    @SerializedName("created_at" ) var createdAt : String? = null,
    @SerializedName("updated_at" ) var updatedAt : String? = null

)
