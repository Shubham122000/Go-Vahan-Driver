package com.transportationapp.ui.fragments

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.viewModels
import androidx.lifecycle.withStarted
import androidx.recyclerview.widget.LinearLayoutManager
import com.transportationapp.R
import com.transportationapp.adapter.OngoingTripAdapter
import com.transportationapp.base.BaseFragment
import com.transportationapp.databinding.FragmentCancelledBookingHistoryBinding
import com.transportationapp.databinding.FragmentPassengerOngoingBinding
import com.transportationapp.model.TripHistoryResponseData
import com.transportationapp.viewmodel.TripHistoryViewModel
import dagger.hilt.android.AndroidEntryPoint
import java.util.ArrayList

@AndroidEntryPoint
class CancelledBookingHistory : BaseFragment() {
    private lateinit var binding: FragmentCancelledBookingHistoryBinding
    val viewModel: TripHistoryViewModel by viewModels()
    var Listdata: ArrayList<TripHistoryResponseData> = ArrayList()
    lateinit var adapter: OngoingTripAdapter
    lateinit var mContext: Context

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = DataBindingUtil.inflate(
            inflater,
            R.layout.fragment_cancelled_booking_history,
            container,
            false
        )
        mContext=this.requireContext()

        // Inflate the layout for this fragment
        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }

        viewModel.cancel_booking_history_loader(
            "Bearer " + userPref.getToken().toString(),
        )
        viewModel.TripHistoryResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                Listdata.clear()
                Listdata.addAll(it.data)
                if (Listdata.size > 0){
                    binding.rvCancelled.layoutManager = LinearLayoutManager(requireContext())
                    adapter = OngoingTripAdapter(requireContext(), Listdata)
                    binding.rvCancelled.adapter = adapter

                }
            else{
                toast(mContext,"No data Found")
                }
////                userPref.setUserId(it!!.data!!.Id.toString())
//                val intent = Intent(this, DashboardActivity::class.java)
//                startActivity(intent)
//                finish()
            } else {
                it.message?.let { it1 -> toast(mContext, it1) }
            }



        }
        return binding.root
    }
}