package com.transportationapp.ui.common

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.databinding.DataBindingUtil
import com.transportationapp.R
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityOtpactivityBinding
import com.transportationapp.ui.DashboardActivity
import com.transportationapp.viewmodel.LoginViewModel
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint

class OTPActivity : BaseActivity() {
    private val mLoginViewModel: LoginViewModel by viewModels()
    private lateinit var binding : ActivityOtpactivityBinding
    var mobile :String =""


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_otpactivity)
        if (intent != null){
            mobile = intent.getStringExtra("mobile_number").toString()
        }
        mLoginViewModel.progressBarStatus.observe(this) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        mLoginViewModel.verifyOtpResponse.observe(this) {
            if (it?.status == 1) {
                val intent = Intent(this, CreatePasswordActivity::class.java)
                intent.putExtra("mobile",mobile)
                startActivity(intent)
                finish()
            } else {
                //toast(it.message)
                snackbar(it?.message!!)
            }
        }

      //  setContentView(R.layout.activity_otpactivity)
//        binding.btnNext.setOnClickListener(View.OnClickListener {

//
//        })
        binding.btnNext.setOnClickListener {
            mLoginViewModel.driverVerifyOtp(
                binding.otpView.text.toString(),
                mobile
            )
        }

    }
}