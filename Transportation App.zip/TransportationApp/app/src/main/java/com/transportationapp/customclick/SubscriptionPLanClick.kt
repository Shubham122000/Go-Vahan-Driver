package com.transportationapp.customclick

import java.text.FieldPosition

interface SubscriptionPLanClick {
    fun PLanClick(payment:String)
}
interface click {
    fun Click(position: Int,url:String)
}