package com.transportationapp.model

class PaymentSubscriptionModelClass {
}