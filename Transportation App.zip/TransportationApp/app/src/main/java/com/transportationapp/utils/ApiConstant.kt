package com.transportationapp.utils

object ApiConstant {

        //Live server url
        const val BASE_URL = "http://182.76.237.238/~apitest/transport/public/api/"
//        const val BASE_URL = "http://172.16.0.238/~apitest/transport/public/api/"
        //Fields Required For Signup
        var name = ""
        var email = ""
        var mobile = ""
        var password = ""
        var  gstNo=""
        var vehicle_registration_no=""
        var deviceID = ""
        var deviceToken = ""
        var gender = ""
        var bank_account_number = ""
        var bank_name = ""
        var branch = ""
        var ifsc_code = ""
        var account_holder_name = ""
        var driver_license_image = ""
        var driver_insurance_image = ""
        var vehicle_number = ""
        var vehicle_manufacture_company = ""
        var vehicle_model = ""
        var vehicle_registration_year = ""
        var vehicle_owner_name = ""
}
