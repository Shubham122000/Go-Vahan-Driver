package com.transportationapp.ui.fragments

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.transportationapp.R
import com.transportationapp.adapter.CompletedTripAdapter
import com.transportationapp.adapter.OngoingTripAdapter
import com.transportationapp.databinding.FragmentCompletedTripHistoryBinding
import com.transportationapp.databinding.FragmentOngoingTripHistoryBinding
import com.transportationapp.model.TripHistoryResponseData
import com.transportationapp.utils.Bookingid
import com.transportationapp.viewmodel.TripHistoryViewModel
import dagger.hilt.android.AndroidEntryPoint
import droidninja.filepicker.fragments.BaseFragment
import java.util.*

@AndroidEntryPoint
class CompletedTripHistoryFragment : com.transportationapp.base.BaseFragment(),Bookingid {
    private lateinit var binding : FragmentCompletedTripHistoryBinding
    private val viewModel: TripHistoryViewModel by viewModels()
    var Listdata:ArrayList<TripHistoryResponseData> = ArrayList()
    lateinit var adapter :CompletedTripAdapter
    var flags :String = "AdapterforLoader"
    lateinit var Bookingid :String
    lateinit var mContext: Context

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_completed_trip_history, container, false)

        mContext=this.requireContext()


        viewModel.progressBarStatus.observe(viewLifecycleOwner) {
            if (it) {
                showProgressDialog()
            } else {
                hideProgressDialog()
            }
        }
        viewModel.CompletedTripHistoryApi(
            "Bearer "+ userPref.getToken().toString(),
        )
        viewModel.TripHistoryResponse.observe(viewLifecycleOwner) {
            if (it?.status == 1) {
                Listdata.clear()
                Listdata.addAll(it.data)
                if (Listdata.size>0){
                    binding.rvCompleted.layoutManager = LinearLayoutManager(requireContext())
                    adapter = CompletedTripAdapter(requireContext(), Listdata,this,flags)
                    binding.rvCompleted.adapter =adapter
                }
                else{
                    toast(mContext,"No data Found")
                }

////                userPref.setUserId(it!!.data!!.Id.toString())
//                val intent = Intent(this, DashboardActivity::class.java)
//                startActivity(intent)
//                finish()
            } else {
//                toast(.message)
            }
        }





        return binding.root
    }

    override fun getbooking(bookingid: String) {
        Bookingid = bookingid

    }


}