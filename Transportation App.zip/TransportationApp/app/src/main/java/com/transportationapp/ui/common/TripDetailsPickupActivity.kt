package com.transportationapp.ui.common

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.transportationapp.R
import com.transportationapp.base.BaseActivity
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class TripDetailsPickupActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trip_details_pickup)
    }
}