package com.transportationapp.ui.common

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.databinding.DataBindingUtil
import com.transportationapp.R
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityLoginAsBinding
import com.transportationapp.ui.vendor.SignUpAsVendor
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class LoginAsActivity : BaseActivity() {
    private lateinit var binding: ActivityLoginAsBinding
    var flag:String = ""
    var flag2:Boolean = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_login_as)

        binding.llIndividual.setOnClickListener {
            flag2 = true
            flag = "INDIVIDUAL"
            binding.Individualyellow.visibility = View.VISIBLE
            binding.Venderyellow.visibility = View.GONE
        }
        binding.llVendor.setOnClickListener {
            flag2 = true
            flag = "VENDER"
            binding.Venderyellow.visibility = View.VISIBLE
            binding.Individualyellow.visibility = View.GONE
        }

        binding.btnContinue.setOnClickListener(View.OnClickListener {
            if (flag2 == false){
                snackbar("Please select atleast one option.")
            }else{
                val intent = Intent(this@LoginAsActivity, SignUpAsVendor::class.java)
                intent.putExtra("flag",flag)
                startActivity(intent)
            }
        })


    }
}