package com.transportationapp.model

class HomeSliderModelCLass (
    val image:Int?=null
    )