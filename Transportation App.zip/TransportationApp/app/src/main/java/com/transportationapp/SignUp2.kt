package com.transportationapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.databinding.DataBindingUtil
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivitySignup2Binding
import com.transportationapp.ui.common.LoginActivity

class SignUp2 : BaseActivity() {
    private lateinit var binding : ActivitySignup2Binding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_signup2)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_signup2)


        binding.btnSubmit.setOnClickListener(View.OnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finishAffinity()

        })

    }
}