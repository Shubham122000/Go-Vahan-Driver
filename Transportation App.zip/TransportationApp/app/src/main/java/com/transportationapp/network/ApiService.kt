package com.transportationapp.network


import com.transportationapp.model.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.*
interface ApiService {

    @FormUrlEncoded
    @POST("driver_register")
    suspend fun driverRegister(
        @Field("name") name: String,
        @Field("mobile") mobile: String,
        @Field("email") email: String,
        @Field("gst_number") gst_number: String,
        @Field("password") password: String,
        @Field("user_type") user_type: String,
//        @Field("type_vehicle") type_vehicle:String,
        @Field("device_type") device_type:String,
        @Field("device_name") device_name:String,
        @Field("device_token") device_token: String,
        @Field("device_id") device_id: String,
    ): Response<RegisterResponseModel>

    @FormUrlEncoded
    @POST("driver_login")
    suspend fun driverLogin(
        @Field("email") email: String,
        @Field("password") password: String,
        @Field("device_token") device_token: String,
        @Field("device_type") device_type: String,
    ): Response<RegisterResponseModel>

    @FormUrlEncoded
    @POST("add_loader_vehicle")
    suspend fun addloadervehical(
        @Header("Authorization") authorization: String,
        @Field("driver_id") driver_iddriver_id: String,
        @Field("vehicle_owner_name") vehicle_owner_name: String,
        @Field("vehicle_name") vehicle_name: String,
        @Field("year_of_model") year_of_model: String,
        @Field("vehicle_number") vehicle_number: String,
        @Field("vehicle_type") vehicle_type: String,
//        @Field("vehicle_category") vehicle_category: String,
        @Field("capacity") capacity: String,
        @Field("height") height: String,
        @Field("color") color: String,
        @Field("no_of_tyres") no_of_tyres: String,
        @Field("body_type") body_type: String,
    ): Response<AddloaderResponse>

    @FormUrlEncoded
    @POST("add_passenger_vehicle")
    suspend fun addpassengervehical(
        @Header("Authorization") authorization: String,
        @Field("driver_id") driver_id: String,
        @Field("owner_name") vehicle_owner_name: String,
        @Field("vehicle_name") vehicle_name: String,
        @Field("year_model") year_of_model: String,
        @Field("vehicle_no") vehicle_number: String,
        @Field("vehicle_type") vehicle_type: String,
//        @Field("vehicle_category") vehicle_category: String,
        @Field("color") color: String,
        @Field("no_tyres") no_of_tyres: String,
        @Field("seat") seat: String,
    ): Response<AddloaderResponse>


    @FormUrlEncoded
    @POST("driver_send_otp")
    suspend fun driverSendOTP(
        @Field("mobile") mobile: String,
    ): Response<RegisterResponseModel>


    @FormUrlEncoded
    @POST("loder_fare_calculator")
    suspend fun loderfarecalculator(
        @Header("Authorization") authorization: String,
        @Field("pickup_lat") pickup_lat: String,
        @Field("pickup_long") pickup_long: String,
        @Field("dropup_lat") dropup_lat: String,
        @Field("dropup_long") dropup_long: String,
        @Field("mileage") mileage: String,
        @Field("vehicle_type") vehicle_type: String,
    ): Response<FareCaluculationResponse>

    @FormUrlEncoded
    @POST("loader_vehicle_payment")
    suspend fun loader_vehicle_payment(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
        @Field("subscribe") subscribe: String,
        @Field("fare") fare: String,
        @Field("payment_mode") payment_mode: String,
       @Field("transaction_id") transaction_id: String,




    ): Response<AddDriverResponse>

    @FormUrlEncoded
    @POST("add_passenger_vehicle_payment")
    suspend fun add_passenger_vehicle_payment(
        @Header("Authorization") authorization: String,
        @Field("id") id: String,
        @Field("subscribe") subscribe: String,
        @Field("fare") fare: String,
        @Field("payment_mode") payment_mode: String,
        @Field("transaction_id") transaction_id: String,
    ): Response<AddDriverResponse>

    @FormUrlEncoded
    @POST("final_vehicle_submition")
    suspend fun FinalvehicalSubmit(
        @Header("Authorization") authorization: String,
        @Field("id") vehicle_id: String,
    ): Response<AddVehicalfinalResponse>

    @FormUrlEncoded
    @POST("final_passenger_vehicle_submition")
    suspend fun FinalpassengerSubmit(
        @Header("Authorization") authorization: String,
        @Field("id") vehicle_id: String,
    ): Response<AddVehicalfinalResponse>

    @Multipart
    @POST("vehicle_idvehicle_img")
    suspend fun passengervehicleimg(
        @Header("Authorization") authorization: String,
        @Part("vehicle_id") vehicle_id: RequestBody,
        @Part image: MultipartBody.Part,
    ): Response<Loaderimage>

    @Multipart
    @POST("passenger_vehicle_doc")
    suspend fun passengervehicledoc(
        @Header("Authorization") authorization: String,
        @Part("vehicle_id") vehicle_id: RequestBody,
        @Part("doc_name") doc_name: RequestBody,
        @Part pdf: MultipartBody.Part,
    ): Response<Loaderimage>

    @Multipart
    @POST("loader_vehicle_img")
    suspend fun loadervehicleimg(
        @Header("Authorization") authorization: String,
        @Part("vehicle_id") vehicle_id: RequestBody,
        @Part image: MultipartBody.Part,
    ): Response<Loaderimage>

    @Multipart
    @POST("loader_vehicle_doc")
    suspend fun loadervehicledoc(
        @Header("Authorization") authorization: String,
        @Part("vehicle_id") vehicle_id: RequestBody,
        @Part("doc_name") doc_name: RequestBody,
        @Part pdf: MultipartBody.Part,
    ): Response<Loaderimage>

    @FormUrlEncoded
    @POST("driver_verfiy_otp")
    suspend fun driverVerifyOtp(
        @Field("otp") otp: String,
        @Field("mobile") mobile: String,
    ): Response<RegisterResponseModel>

    @Multipart
    @POST("create_business_card")
    suspend fun BusinessCardDriver(
        @Header("Authorization") authorization: String,
        @Part("company_name") company_name: RequestBody,
        @Part("full_name") full_name: RequestBody,
        @Part("mobile") mobile: RequestBody,
        @Part("email") email: RequestBody,
        @Part("address") address: RequestBody,
        @Part image: MultipartBody.Part,
    ): Response<CreateBusinesscard>

    @Multipart
    @POST("add_driver_register")
    suspend fun adddriver(
        @Header("Authorization") authorization: String,
        @Part("name") name: RequestBody,
        @Part("driving_exp") driving_exp: RequestBody,
        @Part("driving_lic") driving_lic: RequestBody,
        @Part("mobile") mobile: RequestBody,
        @Part("email") email: RequestBody,
        @Part("password") password: RequestBody,
        @Part profile_image: MultipartBody.Part,
        @Part id_proof: MultipartBody.Part,
        @Part("vendor_id") vendor_id: RequestBody,
        @Part("service_id") service_id: RequestBody,
        ): Response<AddDriverResponse>

    @Multipart
    @POST("user_update_profiile")
    suspend fun EditProfile(
        @Header("Authorization") authorization: String,
        @Part("name") name: RequestBody,
        @Part("email") email: RequestBody,
        @Part("mobile_number") mobile_number: RequestBody,
        @Part("address") address: RequestBody,
        @Part("device_token") device_token: RequestBody,
        @Part("device_type") device_type: RequestBody,
        @Part("device_id") device_id: RequestBody,
        @Part image: MultipartBody.Part
    ): Response<ProfileEditResponse>

    @FormUrlEncoded
    @POST("driver_change_pwd")
    suspend fun driverChangePwd(
        @Header("Authorization") authorization: String,
        @Field("password") password: String,
    ): Response<RegisterResponseModel>

    @GET("loader_driver_vehicle_list")
    suspend fun GetVehicleList(
        @Header("Authorization") authorization: String,
    ): Response<VehicleList>

   @GET("get_passenger_vehicleno")
    suspend fun get_passenger_vehicleno(
        @Header("Authorization") authorization: String,
    ): Response<VehicleNumberPassengerLIst>

  @GET("get_loder_vehicleno")
    suspend fun get_loder_vehicleno(
        @Header("Authorization") authorization: String,
    ): Response<VehicleNumberListMOdelCLass>

    @GET("get_driver_profile")
    suspend fun GetDriverProfile(
        @Header("Authorization") authorization: String,
    ): Response<ProfileResponse>

   @GET("my_driver_wallet_list_donload")
    suspend fun my_driver_wallet_list_donload(
        @Header("Authorization") authorization: String,
    ): Response<ProfileResponse>

    @GET("vehicle_seat")
    suspend fun vehicleSeat(
        @Header("Authorization") authorization: String,
    ): Response<SeatResponse>

    @FormUrlEncoded
    @POST("vendor_driver_list")
    suspend fun driverList(
        @Header("Authorization") authorization: String,
        @Field("vendor_id") vendor_id: String,
    ): Response<DriverListResponse>

    @GET("subscription_plan")
    suspend fun subscriptonplan(
        @Header("Authorization") authorization: String,
    ): Response<SubscriptionPlan>

    @GET("loader_truck_repository_list")
    suspend fun LoaderTruckRepositoryList(
        @Header("Authorization") authorization: String,
    ): Response<LoaderTruckRepositoryListResponse>

    @GET("passengers_truck_repository_list")
    suspend fun LoaderTruckRepositoryLPassengerist(
        @Header("Authorization") authorization: String,
    ): Response<LoaderTruckRepositoryListResponse>

    @FormUrlEncoded
    @POST("diesel_list")
    suspend fun deiselList(
        @Field("id") id: String,
    ): Response<DeiselPrice>

    @GET("state_list")
    suspend fun StateList(): Response<StateListResponse>

    @GET("business_card_details")
    suspend fun Businesscarddetails(
        @Header("Authorization") authorization: String
    ): Response<BusinessListResponse>

    @GET("driver_service_type")
    suspend fun truckType(
    ): Response<TruckTypeResponse>

    @GET("vehicle_type")
    suspend fun TypeofTruck(
        @Header("Authorization") authorization: String
    ): Response<TypeofTruckResponse>

    @GET("body_type")
    suspend fun BodyTpe(
        @Header("Authorization") authorization: String
    ): Response<BodyType>

    @GET("vehicle_color")
    suspend fun Color(
        @Header("Authorization") authorization: String
    ): Response<ColorResponse>

    @GET("year_model")
    suspend fun Year(
        @Header("Authorization") authorization: String
    ): Response<YearResponse>

    @GET("vehicle_wheels")
    suspend fun vehicalwheels(
        @Header("Authorization") authorization: String
    ): Response<vehicalwheelsResponse>

    @GET("height")
    suspend fun Height(
        @Header("Authorization") authorization: String
    ): Response<hightResponse>
    @GET("loader_loader_carming")
    suspend fun Capacity(
        @Header("Authorization") authorization: String
    ): Response<LoaodCarryingResponse>

    @GET("term_condition")
    suspend fun termsCondition(
        @Header("Authorization") authorization: String
    ): Response<RegisterResponseModel>

    @GET("privacy_policy")
    suspend fun privacyPolicy(
        @Header("Authorization") authorization: String
    ): Response<RegisterResponseModel>

    @GET("about_us")
    suspend fun aboutUs(
        @Header("Authorization") authorization: String
    ): Response<RegisterResponseModel>

    @GET("contact_us")
    suspend fun contactus(
        @Header("Authorization") authorization: String
    ): Response<RegisterResponseModel>

    @GET("driver_get_profile")
    suspend fun getProfile(
        @Header("Authorization") authorization: String
    ): Response<ListResponseData>

    @GET("ongoing_driver_trip_history_loader")
    suspend fun OngoingTripHistory(
        @Header("Authorization") authorization: String
    ): Response<TripHistoryResponse>

   @GET("cancel_booking_history_loader")
    suspend fun cancel_booking_history_loader(
        @Header("Authorization") authorization: String
    ): Response<TripHistoryResponse>

  @GET("cnacel_booking_passengers")
    suspend fun cnacel_booking_passengers(
        @Header("Authorization") authorization: String
    ): Response<TripHistoryResponse>

    @GET("ongoing_booking_passengers")
    suspend fun OngoingTripHistoryPassenger(
        @Header("Authorization") authorization: String
    ): Response<TripHistoryResponse>

    @GET("loder_driver_cancel_reasons_list")
    suspend fun loadercancellationReasonlist(
        @Header("Authorization") authorization: String
    ): Response<Loader_cancel_ReasonList_Response>

    @GET("upcooming_booking_loder")
    suspend fun UpcomingsTripHistory(
        @Header("Authorization") authorization: String
    ): Response<TripHistoryResponse>

    @GET("upcooming_booking_passengers")
    suspend fun UpcomingsPassengerTripHistory(
        @Header("Authorization") authorization: String
    ): Response<TripHistoryResponse>

    @GET("completed_driver_trip_history_loader")
    suspend fun CompletedTripHistory(
        @Header("Authorization") authorization: String
    ): Response<TripHistoryResponse>

    @GET("completed_booking_passengers")
    suspend fun CompletedTripHistoryPassenger(
        @Header("Authorization") authorization: String
    ): Response<TripHistoryResponse>

    @FormUrlEncoded
    @POST("loader_driver_trip_cancel")
    suspend fun LoaderdrivertripHistory(
        @Header("Authorization") authorization: String,
        @Field("booking_id") booking_id:String,
        @Field("reasons_id") reasons_id:String,
        @Field("message") message:String
    ): Response<LoaderDriverTripCancelResponse>

    @FormUrlEncoded
    @POST("driver_profile")
    suspend fun driverProfile(
        @Header("Authorization") authorization: String,
        @Field("id") booking_id:String,
    ): Response<DriverProfile>

    @FormUrlEncoded
    @POST("loader_truck_repository_list_details")
    suspend fun loader_truck_repository_list_details(
        @Header("Authorization") authorization: String,
        @Field("vehicle_id") vehicle_id:String,
    ): Response<TaxiRepositoryViewDetailsResponse>

    @FormUrlEncoded
    @POST("loader_truck_repository_image_list_details")
    suspend fun loader_truck_repository_image_list_details(
        @Header("Authorization") authorization: String,
        @Field("vehicle_id") vehicle_id:String,
    ): Response<TruckImagesModelCLass>

  @FormUrlEncoded
    @POST("passengers_truck_repository_image_list")
    suspend fun passengers_truck_repository_image_list(
        @Header("Authorization") authorization: String,
        @Field("vehicle_id") vehicle_id:String,
    ): Response<TruckImagesModelCLass>

    @FormUrlEncoded
    @POST("loader_truck_repository_doc_list_details")
    suspend fun loader_truck_repository_doc_list_details(
        @Header("Authorization") authorization: String,
        @Field("vehicle_id") vehicle_id:String,
    ): Response<TruckDocumentsDetailsResponse>

    @FormUrlEncoded
    @POST("passengers_truck_repository_list_details")
    suspend fun passengers_truck_repository_list_details(
        @Header("Authorization") authorization: String,
        @Field("vehicle_id") vehicle_id:String,
    ): Response<TaxiRepositoryViewDetailsResponse>

  @FormUrlEncoded
    @POST("passengers_truck_repository_doc_list")
    suspend fun passengers_truck_repository_doc_list(
        @Header("Authorization") authorization: String,
        @Field("vehicle_id") vehicle_id:String,
    ): Response<TruckDocumentsDetailsResponse>

   @FormUrlEncoded
    @POST("loader_trip_delete")
    suspend fun loader_trip_delete(
        @Header("Authorization") authorization: String,
        @Field("id") id:String,
    ): Response<DriverProfile>

   @FormUrlEncoded
    @POST("loader_truck_repository_list_delete")
    suspend fun loader_truck_repository_list_delete(
        @Header("Authorization") authorization: String,
        @Field("vehicle_id") vehicle_id:String,
    ): Response<DriverProfile>

   @FormUrlEncoded
    @POST("passengers_truck_repository_list_delete")
    suspend fun passengers_truck_repository_list_delete(
        @Header("Authorization") authorization: String,
        @Field("vehicle_id") vehicle_id:String,
    ): Response<DriverProfile>

   @FormUrlEncoded
    @POST("vendor_driver_delete")
    suspend fun vendor_driver_delete(
        @Header("Authorization") authorization: String,
        @Field("id") id:String,
    ): Response<DriverProfile>

   @FormUrlEncoded
    @POST("my_wallet_payment")
    suspend fun my_wallet_payment(
        @Header("Authorization") authorization: String,
        @Field("type") type:String,
        @Field("transaction_id") transaction_id:String,
        @Field("amount") amount:String,
    ): Response<DriverProfile>

   @FormUrlEncoded
    @POST("add_bank_account")
    suspend fun add_bank_account(
        @Header("Authorization") authorization: String,
        @Field("account_no") account_no:String,
        @Field("name") name:String,
        @Field("ifsc") ifsc:String,
        @Field("bank_name") bank_name:String,
        @Field("account_branch") account_branch:String,
    ): Response<DriverProfile>

    @Multipart
    @POST("loader_builty_img")
    suspend fun loader_builty_img(
        @Header("Authorization") authorization: String,
        @Part("booking_id") booking_id:RequestBody,
        @Part pod: MultipartBody.Part?,
        @Part signature: MultipartBody.Part?,
        @Part builty: MultipartBody.Part?,
    ): Response<DriverProfile>

    @FormUrlEncoded
    @POST("lode_ride_completed")
    suspend fun rideCompleted(
        @Header("Authorization") authorization: String,
        @Field("booking_id") booking_id:String,
    ): Response<RideCompletedResponse>



    @FormUrlEncoded
    @POST("loader_driver_start_trip")
    suspend fun AcceptRide(
        @Header("Authorization") authorization: String,
        @Field("booking_id") booking_id:String,
        @Field("start_code") start_code:String,
    ): Response<Addmoneywallet>

    @Multipart
    @POST("driver_update_profiile")
    suspend fun Updatedriver(
        @Header("Authorization") authorization: String,
        @Part("id") id:RequestBody,
        @Part("name") name:RequestBody,
        @Part("mobile_number") mobile_number:RequestBody,
        @Part("experience") experience:RequestBody,
        @Part("licence_number") licence_number:RequestBody,
        @Part("device_token") device_token:RequestBody,
        @Part("device_type") device_type:RequestBody,
        @Part("device_id") device_id:RequestBody,
        @Part("password") password:RequestBody,
        @Part image: MultipartBody.Part
    ): Response<DriverUpdateProfileResponse>

    @GET("completed_driver_trip_history_loader_details")
    suspend fun CompletedHistoryDetails(
        @Header("Authorization") authorization: String,
        @Header("booking_id") booking_id: String
    ): Response<TripHistoryResponse>

    @GET("my_driver_wallet_list")
    suspend fun Mywalletlist(
        @Header("Authorization") authorization: String
    ): Response<WalletListResponse>

    @GET("loder_transaction_report")
    suspend fun Transactionreport(
        @Header("Authorization") authorization: String
    ): Response<TransactionReportResponse>

    @GET("visiting_card_url")
    suspend fun Visitingcardurl(
        @Header("Authorization") authorization: String
    ): Response<VisitingCardUrlResponse>

    @GET("loader_contact_us")
    suspend fun ContactUS(
        @Header("Authorization") authorization: String
    ): Response<ContactUSRsponse>

    @GET("loder_about_us")
    suspend fun AboutUS(
        @Header("Authorization") authorization: String
    ): Response<AboutUs>

    @GET("loader_privacy_policy")
    suspend fun PrivacyPolicy(
        @Header("Authorization") authorization: String
    ): Response<PrivacyPolicy>

    @GET("loader_notification_list")
    suspend fun Notification(
        @Header("Authorization") authorization: String
    ): Response<NotificationResponse>

    @GET("driver_rating")
    suspend fun Ratings(
        @Header("Authorization") authorization: String
    ): Response<RatingResponse>

    @GET("visiting_cardPDF")
    suspend fun Visitingcardpdf(
        @Header("Authorization") authorization: String
    ): Response<DownloadPdfResponse>

    @FormUrlEncoded
    @POST("invoice_cardPDF")
    suspend fun InvoiceDownload(
        @Header("Authorization") authorization: String,
        @Field("invoice_numbers") invoice_numbers:String
    ): Response<DownloadPdfResponse>

    @FormUrlEncoded
    @POST("add_driver_my_wallet")
    suspend fun Addmoneywallet(
        @Header("Authorization") authorization: String,
        @Field("amount") amount:String
    ): Response<Addmoneywallet>

    @POST("loader_trip_list")
    suspend fun LoaderTripList(
        @Header("Authorization") authorization: String,
    ): Response<TripListResponse>

    @GET("passenger_trip_list")
    suspend fun PassengerTripList(
        @Header("Authorization") authorization: String,
    ): Response<TripListResponse>

    @GET("self_driver_trip")
    suspend fun self_driver_trip(
        @Header("Authorization") authorization: String,
    ): Response<AddTripDriverMOdelClass>

    @GET("self_driver_passenger_trip")
    suspend fun self_driver_passenger_trip(
        @Header("Authorization") authorization: String,
    ): Response<AddTripDriverMOdelClass>

    @GET("loader_driver_invoice_list")
    suspend fun InvoiceList(
        @Header("Authorization") authorization: String,
    ): Response<InvoiceListResponse>

    @FormUrlEncoded
    @POST("my_driver_wallet_filter_list")
    suspend fun walletfiltered(
        @Header("Authorization") authorization: String,
        @Field("date") date:String,
        @Field("transaction_type") transaction_type:String,
    ): Response<WalletFilterLIstREsponse>


    @FormUrlEncoded
    @POST("completed_driver_trip_history_loader_details")
    suspend fun Completedrivertripdetails(
        @Header("Authorization") authorization: String,
        @Field("booking_id") booking_id:String
    ): Response<CompleteDriverDetailsResponse>

    @FormUrlEncoded
    @POST("completed_booking_history_passengers_details")
    suspend fun CompletedriverPassengertripdetails(
        @Header("Authorization") authorization: String,
        @Field("booking_id") booking_id:String
    ): Response<CompleteDriverDetailsResponse>


    @FormUrlEncoded
    @POST("send_driver_loader_invoice")
    suspend fun SendDriverLoaderInvoice(
        @Header("Authorization") authorization: String,
        @Field("booking_id") booking_id:String
    ): Response<SendDriverLoaderInvoiceResponse>

    @FormUrlEncoded
    @POST("loader_driver_invoice_details")
    suspend fun LoaderinvoiceSummery(
        @Header("Authorization") authorization: String,
        @Field("invoice_numbers") invoice_numbers:String
    ): Response<InvoiceSummeryResponse>

//    @FormUrlEncoded
//    @POST("loader_driver_invoice_details")
//    suspend fun Loaderinvoice(
//        @Header("Authorization") authorization: String,
//        @Field("invoice_numbers") invoice_numbers:String
//    ): Response<InvoiceResponse>


    @FormUrlEncoded
    @POST("add_loader_trip")
    suspend fun AddTrip(
        @Header("Authorization") authorization: String,
        @Field("tip_task") tip_task: String,
        @Field("load_caring") load_caring: String,
        @Field("from_trip") from_trip: String,
        @Field("to_trip") to_trip: String,
        @Field("vehicle_type") vehicle_type: String,
        @Field("vehicle_numbers") vehicle_numbers: String,
        @Field("no_tyers") no_tyers: String,
        @Field("body_type") body_type: String,
        @Field("assign_driver") assign_driver: String,
        @Field("total_distance") total_distance: String,
        @Field("freight_amount") freight_amount: String,
        @Field("pickup_lat") pickup_lat: String,
        @Field("pickup_long") pickup_long: String,
        @Field("dropup_lat") dropup_lat: String,
        @Field("dropup_long") dropup_long: String,
        @Field("vehicle_id") vehicle_id: String,
        @Field("booking_date_from") booking_date_from: String,
        @Field("booking_time") booking_time: String,
    ): Response<CreateBusinesscard>

    @FormUrlEncoded
    @POST("add_passenger_trip")
    suspend fun AddTripPassenger(
        @Header("Authorization") authorization: String,
        @Field("tip_task") tip_task: String,
        @Field("load_caring") load_caring: String,
        @Field("from_trip") from_trip: String,
        @Field("to_trip") to_trip: String,
        @Field("vehicle_type") vehicle_type: String,
        @Field("vehicle_numbers") vehicle_numbers: String,
        @Field("no_tyers") no_tyers: String,
        @Field("body_type") body_type: String,
        @Field("assign_driver") assign_driver: String,
        @Field("total_distance") total_distance: String,
        @Field("freight_amount") freight_amount: String,
        @Field("pickup_lat") pickup_lat: String,
        @Field("pickup_long") pickup_long: String,
        @Field("dropup_lat") dropup_lat: String,
        @Field("dropup_long") dropup_long: String,
        @Field("vehicle_id") vehicle_id: String,
        @Field("booking_date_from") booking_date_from: String,
        @Field("booking_time") booking_time: String,

    ): Response<CreateBusinesscard>


    @FormUrlEncoded
    @POST("driver_forgot_pwd")
    suspend fun changePass(
//        @Header("Authorization") token: String,
//        @Field("oldPassword") password: String,
        @Field("mobile") mobile: String,
        @Field("password") new_password: String,


        ): Response<RegisterResponseModel>

    /*
    @FormUrlEncoded
    @POST("userCategory")
    suspend fun categoryClick(
        @Field("user_id") user_id: String,
        @Field("category_id") category_id: String,
    ): Response<CategoryRequestModel>

    @GET("about_us")
    suspend fun aboutUs(
        @Header("Authorization") authorization: String
    ): Response<AuthResponse>


    @FormUrlEncoded
    @POST("viewUserDetail")
    suspend fun getProfile(
        @Field("user_id") userId: String
    ): Response<ProfileModel>

    @FormUrlEncoded
    @POST("likePost")
    suspend fun callLikeApi(
        @Field("user_id") userId: String,
        @Field("post_id") post_id: String,
        @Field("status") status: String,
    ): Response<LikeModel>

    @FormUrlEncoded
    @POST("notificationList")
    suspend fun getNotificationList(
        @Field("user_id") userId: String
    ): Response<NotificationResponseModel>

    @FormUrlEncoded
    @POST("userDetail")
    suspend fun getProfileData(
        @Field("user_id") userId: String
    ): Response<EditProfileModel>

    @GET("termscondition")
    suspend fun termsCondition(
        @Header("Authorization") authorization: String
    ): Response<AuthResponse>

    @FormUrlEncoded
    @POST("send_otp")
    suspend fun sendOtp(
        @Field("username") username: String
    ): Response<AuthResponse>

    @FormUrlEncoded
    @POST("change_password")
    suspend fun changePass(
        @Header("Authorization") token: String,
        @Field("oldPassword") password: String,
        @Field("password") new_password: String,
        @Field("user_id") user_id: String,

    ): Response<ChangePasswordResponseModel>

    @FormUrlEncoded
    @POST("forgot_password")
    suspend fun forgotPass(
        @Header("Authorization") authorization: String,
        @Field("username") username: String,
        @Field("password") new_password: String
    ): Response<ChangePassModel>

    @FormUrlEncoded
    @POST("contactus")
    suspend fun contactUs(

        @Field("name") name: String,
        @Field("email") email: String,
        @Field("mobile") mobile: String,
        @Field("message") message: String
    ): Response<AuthResponse>

    @Multipart
    @POST("edit_profile")
    suspend fun updateProfile(
        @Part image: MultipartBody.Part,
        @Part("username") name : RequestBody,
        @Part("email") email : RequestBody,
        @Part("phoneNumber") mobile : RequestBody,
        @Part("_id") userId : RequestBody
    ):Response<EditProfileModel>






    @FormUrlEncoded
    @POST("postList")
    suspend fun homeApi(
        @Field("user_id") user_id: String
    ): Response<HomeApiResponse>


    @GET("registrationList")
    suspend fun registrationDataList(
    ): Response<RegisterationDataList>



    @FormUrlEncoded
    @POST("postDetail")
    suspend fun postDetailApi(
        @Field("post_id") post_id: String
    ): Response<PostDetailModel>


    @POST(AppConstant.CATEGORY_LIST_URL)
    suspend fun categoryListApi(
    ): Response<CategoryListModel>*/


}