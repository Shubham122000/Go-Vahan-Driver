package com.transportationapp.ui.common

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.transportationapp.R

class UploadSignature : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload_signature)
    }
}