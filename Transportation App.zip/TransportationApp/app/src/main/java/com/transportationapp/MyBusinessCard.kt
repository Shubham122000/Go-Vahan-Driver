package com.transportationapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatDelegate
import androidx.databinding.DataBindingUtil
import com.transportationapp.base.BaseActivity
import com.transportationapp.databinding.ActivityMyBusinessCardBinding

class MyBusinessCard : BaseActivity() {

    lateinit var binding : ActivityMyBusinessCardBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding = DataBindingUtil.setContentView(this, R.layout.activity_my_business_card)






    }
}