package com.transportationapp.utils;

public interface DownloadListener{
    void onDownloadComplete();
    void onDownloadStart();
}