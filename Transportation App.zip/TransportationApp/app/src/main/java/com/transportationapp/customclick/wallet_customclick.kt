package com.transportationapp.customclick

interface wallet_customclick {

    fun onItemClick(id:String)

}
interface tripdelete {

    fun tripdelete(id:String)

}
interface loadervehiclelist {

    fun loadervehiclelist(id: String?)

}