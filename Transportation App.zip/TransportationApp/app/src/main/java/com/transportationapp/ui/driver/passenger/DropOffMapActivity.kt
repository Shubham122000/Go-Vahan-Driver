package com.transportationapp.ui.driver.passenger

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.transportationapp.R

class DropOffMapActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_drop_off_map)
    }
}